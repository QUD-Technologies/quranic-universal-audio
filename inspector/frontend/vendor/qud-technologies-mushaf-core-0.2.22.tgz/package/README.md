# @qud-technologies/mushaf-core

Headless Mushaf core: page view models, spreads, sizing, navigation, highlights, hits, events and
the tajweed colour mapping. Pure TS, no DOM. Contract: [`spec/README.md`](../../spec/README.md).

```ts
import { openPack } from "@qud-technologies/quran-data";
import { createMushaf } from "@qud-technologies/mushaf-core";

const pack = openPack(await (await fetch(packUrl)).arrayBuffer());
const mushaf = createMushaf({ pack, layout: "madani-1421", mode: "auto", start: savedAnchor, measure });
mushaf.on("pageChange", ({ anchor }) => save(anchor));
mushaf.resize({ width: el.clientWidth, height: el.clientHeight });
for (const view of mushaf.currentViews()) draw(view, mushaf.segments(view.page), mushaf.viewFontPx());
mushaf.hit({ page, line, word, gesture: "tap" }); // emits wordTap / ayahTap / ...
```

What every app of the Mushaf computes alike is a separate entry, `@qud-technologies/mushaf-core/app`,
held to the `conformance/fixtures/app*.json` fixtures: the reader's logic (go-to grammar and
surah-name folding, the nav index, copied verse text, the tajweed legend, print differences,
number and reference formatting) and the player's (following the recitation, the play queue and
repeat plans, the reciter handover, the ayah strip, the peek, the read-along state). Pure
functions and state machines, clock and input injected.

Peer dependency: `@qud-technologies/quran-data` ^1.9.0, installed from the talqeen-ai-data release tarball (`qud-technologies-quran-data-<v>.tgz`, pinned by sha256), not the npm registry.
