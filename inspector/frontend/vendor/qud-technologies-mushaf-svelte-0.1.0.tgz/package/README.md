# @qud-technologies/mushaf-svelte

Svelte 5 wrapper over [`<qud-mushaf>`](../web/): the element's options and inputs as props,
its events as callback props (argument: the event `detail`), its slots as snippets.

```svelte
<script lang="ts">
  import { QudMushaf } from "@qud-technologies/mushaf-svelte";
  let element = $state<HTMLElementTagNameMap["qud-mushaf"]>();
</script>

<QudMushaf
  bind:element
  packUrl="/data/quran-core.qref"
  fontBase="/fonts/"
  mode="auto"
  start="2:255"
  highlights={[{ id: "now", target: "2:255", style: "band" }]}
  onWordTap={(d) => console.log(d.anchor)}
  onPageChange={(d) => (saved = d.anchor)}
>
  {#snippet footer(chrome)}<span>{chrome.page}</span>{/snippet}
</QudMushaf>
```

Props: `pack`, `packUrl`, `fontBase`, `fontUrl`, `layout`, `mode`, `sizing`, `theme`, `locale`,
`chrome`, `highlights`, `tajweed`, `interaction`, `surahHeaderStyle`, `ayahMarker`, `start`, `canNavigate`, `labels`, `navButtons`,
`class`, `style`, `element` (bindable). Callbacks: `onWordTap`, `onWordLongPress`, `onAyahTap`,
`onAyahLongPress`, `onSurahHeaderTap`, `onPageNumberTap`, `onPageChange`, `onVisiblePagesChange`,
`onReady`, `onError`, `onMountChange`. Snippets: `header(chrome: PageChrome)`,
`footer(chrome: PageChrome)`, `surahHeader({surah, page, line})`, drawn for mounted pages only.
The package ships its `.svelte` source (`svelte` export condition); compile it with your app.
