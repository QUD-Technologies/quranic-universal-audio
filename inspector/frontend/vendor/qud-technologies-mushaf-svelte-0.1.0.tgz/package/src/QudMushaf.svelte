<!--
  Svelte 5 wrapper over <qud-mushaf>: every option is a prop, every event a callback prop
  (`onWordTap`, `onPageChange`, ...; the argument is the event's detail), and the element's
  per-page slots are snippets (`header(chrome)`, `footer(chrome)`, `surahHeader(slot)`), drawn
  for the mounted pages only. `bind:element` gives the element for goTo / next / prev.
-->
<script module lang="ts">
  import type {
    EventMap, GoToTarget, Highlight, HitPayload, MushafOptions, PageChangePayload, PageChrome, PagePredicate,
    ReadyPayload, ErrorPayload, VisiblePagesPayload,
  } from "@qud-technologies/mushaf-core";
  import type { FontUrlFn, Labels, MountedSlots, QudMushafElement, SurahHeaderSlot } from "@qud-technologies/mushaf-web";
  import type { QuranPack } from "@qud-technologies/quran-data";
  import type { Snippet } from "svelte";

  export interface QudMushafProps {
    pack?: QuranPack | null;
    packUrl?: string | null;
    fontBase?: string | null;
    fontUrl?: FontUrlFn | null;
    layout?: string;
    mode?: MushafOptions["mode"];
    sizing?: MushafOptions["sizing"];
    theme?: MushafOptions["theme"];
    locale?: string;
    chrome?: MushafOptions["chrome"];
    highlights?: Highlight[];
    tajweed?: MushafOptions["tajweed"];
    interaction?: MushafOptions["interaction"];
    start?: GoToTarget;
    canNavigate?: PagePredicate | null;
    labels?: Partial<Labels>;
    navButtons?: boolean;
    header?: Snippet<[PageChrome]>;
    footer?: Snippet<[PageChrome]>;
    surahHeader?: Snippet<[SurahHeaderSlot]>;
    onWordTap?: (detail: HitPayload) => void;
    onWordLongPress?: (detail: HitPayload) => void;
    onAyahTap?: (detail: HitPayload) => void;
    onAyahLongPress?: (detail: HitPayload) => void;
    onSurahHeaderTap?: (detail: HitPayload) => void;
    onPageNumberTap?: (detail: HitPayload) => void;
    onPageChange?: (detail: PageChangePayload) => void;
    onVisiblePagesChange?: (detail: VisiblePagesPayload) => void;
    onReady?: (detail: ReadyPayload) => void;
    onError?: (detail: ErrorPayload) => void;
    onMountChange?: (detail: MountedSlots) => void;
    element?: QudMushafElement;
    class?: string;
    style?: string;
  }

  const EVENTS = [
    "wordTap", "wordLongPress", "ayahTap", "ayahLongPress", "surahHeaderTap", "pageNumberTap",
    "pageChange", "visiblePagesChange", "ready", "error", "mountChange",
  ] as const satisfies readonly (keyof EventMap | "mountChange")[];

  /** `wordTap` → `onWordTap`. */
  const callbackOf = (name: string): string => `on${name[0]!.toUpperCase()}${name.slice(1)}`;
</script>

<script lang="ts">
  import "@qud-technologies/mushaf-web";

  let { element = $bindable(), header, footer, surahHeader, class: className, style, ...props }: QudMushafProps = $props();
  let mounted = $state.raw<MountedSlots>({ pages: [], surahHeaders: [] });

  // Options and inputs are properties of the element; `undefined` restores a default.
  $effect(() => {
    if (element && props.pack) element.pack = props.pack;
  });
  $effect(() => { if (element) element.start = props.start; });
  $effect(() => { if (element) element.packUrl = props.packUrl ?? null; });
  $effect(() => { if (element) element.fontBase = props.fontBase ?? null; });
  $effect(() => { if (element) element.fontUrl = props.fontUrl ?? null; });
  $effect(() => { if (element) element.canNavigate = props.canNavigate ?? null; });
  $effect(() => { if (element) element.labels = props.labels ?? {}; });
  $effect(() => { if (element) element.navButtons = props.navButtons ?? false; });
  $effect(() => {
    if (!element) return;
    const { layout, mode, sizing, theme, locale, chrome, tajweed, interaction } = props;
    element.setOptions({ layout, mode, sizing, theme, locale, chrome, tajweed, interaction });
  });
  $effect(() => { if (element) element.setHighlights(props.highlights ?? []); });

  $effect(() => {
    const el = element;
    if (!el) return;
    const handlers = EVENTS.map((name) => {
      const fn = (e: Event) => {
        const detail = (e as CustomEvent).detail;
        if (name === "mountChange") mounted = detail as MountedSlots;
        ((props as Record<string, unknown>)[callbackOf(name)] as ((d: unknown) => void) | undefined)?.(detail);
      };
      el.addEventListener(name, fn);
      return [name, fn] as const;
    });
    mounted = el.mounted;
    return () => handlers.forEach(([name, fn]) => el.removeEventListener(name, fn));
  });
</script>

<qud-mushaf bind:this={element} class={className} {style}>
  {#if header}
    {#each mounted.pages as chrome (chrome.page)}
      <div slot={`header-${chrome.page}`} style="display: contents">{@render header(chrome)}</div>
    {/each}
  {/if}
  {#if footer}
    {#each mounted.pages as chrome (chrome.page)}
      <div slot={`footer-${chrome.page}`} style="display: contents">{@render footer(chrome)}</div>
    {/each}
  {/if}
  {#if surahHeader}
    {#each mounted.surahHeaders as slot (slot.surah)}
      <div slot={`surah-header-${slot.surah}`} style="display: contents">{@render surahHeader(slot)}</div>
    {/each}
  {/if}
</qud-mushaf>
