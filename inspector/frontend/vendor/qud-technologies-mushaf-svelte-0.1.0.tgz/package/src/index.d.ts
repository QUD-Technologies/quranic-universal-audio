export { default as QudMushaf } from "./QudMushaf.svelte";
export type { QudMushafProps } from "./QudMushaf.svelte";
