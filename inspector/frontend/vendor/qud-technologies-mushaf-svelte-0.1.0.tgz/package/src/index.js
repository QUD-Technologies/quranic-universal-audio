export { default as QudMushaf } from "./QudMushaf.svelte";
