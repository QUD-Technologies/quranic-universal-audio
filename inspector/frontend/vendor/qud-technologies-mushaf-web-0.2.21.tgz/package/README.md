# @qud-technologies/mushaf-web

`<qud-mushaf>`: a framework-free custom element drawing the Mushaf as DOM text over
[`@qud-technologies/mushaf-core`](../core-ts/). Importing the package defines the element.
Contract: [`spec/README.md`](../../spec/README.md).

```html
<qud-mushaf pack-url="/data/quran-core.qref" font-base="/fonts/" layout="madani-1421" mode="auto" start="2:255"></qud-mushaf>
<script type="module">
  import "@qud-technologies/mushaf-web";
  const el = document.querySelector("qud-mushaf");
  el.addEventListener("wordTap", (e) => console.log(e.detail.anchor));
  el.addEventListener("pageChange", (e) => localStorage.anchor = e.detail.anchor);
  el.setHighlights([{ id: "now", target: "2:255", style: "band" }]);
</script>
```

Give the element a size (it fills its box). Data and fonts come from the `talqeen-ai-data`
releases only: the pack (`pack` or `pack-url`) and the fonts its `fonts()` describes, served where
`fontUrl(id, font)` (or `font-base` + `font.file`) says. Each font registers as family `qm-<id>`.

## Attributes (shorthands)

| Attribute | Option |
|---|---|
| `layout` | `layout` (`madani-1405`, `madani-1421`, `madani-1441`) |
| `mode` | `mode` (`page`, `spread`, `auto`, `scroll`) |
| `sizing`, `font-px` | `sizing.policy`, `sizing.fontPx` |
| `scheme` | `theme.scheme` (`light`, `dark`) |
| `locale` | `locale` |
| `tajweed` (boolean) | `tajweed.enabled` |
| `long-press-ms` | `interaction.longPressMs` |
| `start` | where to open: an anchor `s:a:w` or `s:a` (read once, when it first draws) |
| `pack-url`, `font-base` | where the pack and the font files are |
| `nav-buttons` (boolean) | page-turn buttons beside the book, in 44px slots |

## Properties and methods

Every core option is a property: `layout`, `mode`, `sizing`, `theme`, `locale`, `chrome`,
`highlights`, `tajweed`, `interaction`, `surahHeaderStyle`, `ayahMarker` (`undefined` restores the default), and `setOptions(patch)`
sets several. Also `pack`, `packUrl`, `fontBase`, `fontUrl`, `start` (any `GoToTarget`),
`canNavigate(page)`, `labels` (`juz`, `hizb`, `page`, `next`, `prev`, `surah`; `{n}`/`{name}`
placeholders; built in: `ar`, `en`), `navButtons`, and `lines` (`{ from, to }`, 1-based, page
mode: only those lines of a page, sized as on the full page, without running head, page number or
frame, the first at the top; a close-up crops it as is).

| Member | |
|---|---|
| `goTo(target)` | jump (no slide); false when it cannot |
| `next()`, `prev()` | turn one view, sliding in paged modes; false at the edge |
| `setHighlights(list)` | replace highlights (no page rebuild) |
| `anchor()` | the anchor to persist |
| `controller`, `state` | the core controller and its state (null until loaded) |
| `mounted` | `{pages: PageChrome[], surahHeaders: {surah, page, line}[]}` of the mounted pages |

## Events

CustomEvents named as the core's, `detail` = the core payload: `wordTap`, `wordLongPress`,
`ayahTap`, `ayahLongPress`, `surahHeaderTap`, `pageNumberTap` (`{anchor, ayah, page, line,
rect}`; `rect` in client px), `pageChange`, `visiblePagesChange`, `ready`, `error`. Plus
`mountChange` (`detail` as `mounted`) whenever the mounted pages change, for filling slots.

## Slots

Per mounted page `header-<page>` and `footer-<page>`, and `surah-header-<surah>` for a surah's
header line (once in a layout). Unfilled slots show the default drawing.

## Styling

Theme tokens are custom properties `--qm-<token>` (`background`, `page`, `text`, `frame`,
`chrome`, `highlight-text`, `highlight-fill`, `highlight-band`, `highlight-underline`,
`dim-opacity`); a consumer's CSS on the element wins. Tajweed colours come from
`tajweed.preset` (a data SDK preset, `classic` by default, light or dark palette by scheme) and
`tajweed.colours` overrides keyed by style key; the element writes them for the scheme as
`--qm-tj-<style key>` (pages refer to those, so a scheme change rebuilds no page). Web only: `--qm-ui-font`, `--qm-marker`, `--qm-spine`,
`--qm-band-radius`; page turns: `--qm-turn-ms` (one page, 280ms), `--qm-turn-spread-ms` (a spread's
leaf, 340ms), `--qm-turn-fade-ms` (the crossfade under reduced motion, 120ms), `--qm-turn-ease`,
`--qm-turn-parallax` (0.7: the page under moves that share as far) and `--qm-turn-perspective`;
set by the element from `sizing.pad`: `--qm-pad-block`, `--qm-pad-inline` (em). Parts: `root`, `page`, `header`, `footer`, `word` (plus
`hl-<style>` per highlight, e.g. `::part(hl-active)` for a consumer token), `band`, `nav`,
`nav-next`, `nav-prev`, `status`.

## Touch and keys

Tap and long press on words, markers, surah headers and the page number; horizontal swipe turns
pages right to left (finger to the right = next); `touch-action: pan-y pinch-zoom` leaves vertical
pans and zoom to the browser; on coarse pointers text selection and the touch callout are off and
a long press suppresses the context menu. With focus, ←/→ turn pages (← is next).

## Paged modes

The view and its neighbours are mounted. A turn hands the views new slots (the next view becomes
the current one in place) rather than moving pages; the views a further turn either way needs are
built ahead in idle time, in slices of a few milliseconds, and laid out there, so a turn only
shows them. Off-stage neighbours are `content-visibility: hidden` (a theme change restyles the
pages on show only). When every page must be redrawn, the view on show is drawn at once and its
neighbours just after, in idle time (`mounted` lists them once they are).

## What redraws

Nothing but the pages' structure: colours (theme tokens, `tajweed.colours`, frame and marker
colours) are custom properties, so a colour or theme change is a new stylesheet; on justified
pages tajweed on/off is too (glyphs are split into tajweed runs either way; off, no `--qm-tj-*`
is written), except while `reading.letters` is on. A `locale` or `labels` change redraws the
running head, page number and surah headers in place. A justified line is drawn merged (a path
per colour); a highlight that styles glyphs, or the read-along playhead, splits its line into a
group per word (`part="word"`) while it lasts. A layout switch keeps the pages on show until the
new layout's justification has loaded, so they are never painted unjustified.

## Scroll mode

The scroller shows no scrollbar (hosts navigate with their own controls); wheel and touch scroll
it, and with the element focused so do ↑/↓, Page Up/Down, Space and Home/End. The pages on screen
and one either side are mounted. Mounted pages stay in place as others come and go, and are
contained (`contain: strict`, `content-visibility: auto`). While the scroll is faster than about
three pages a second, a page not built yet is a blank shell of its size (`--qm-page`); once it
slows, they are built a step per frame (data, DOM, placement), and the next page is built ahead
in idle time. `mounted` and `mountChange` list the built pages only.

## e2e

`npm run e2e` (not in CI) runs Playwright on Chromium, Firefox and WebKit against the dev pages
in `e2e/site/` (`node packages/web/e2e/serve.mjs`), after `npm run data`. Where Playwright's
Firefox will not start from `%LOCALAPPDATA%` (Windows "side-by-side configuration"), move it and
set `E2E_FIREFOX=<path>/firefox.exe`. A clean run takes under a minute per browser. On Windows,
Playwright's WebKit (and, reported, Firefox) now and then does not exit on close: the run then
prints `worker-N process did not exit within 300000ms after stop, force-killed it` and takes five
minutes longer, with every test result unaffected (seen with `DEBUG=pw:browser`: graceful close
starts, the process is gone at the forced kill, its exit is never reported).

### Tajweed on WebKit

WebKit paints a combining mark in the colour of the letter it sits on, whatever element holds the
mark: a mark run keeps its base letter's colour, with or without the SDK's word joiner (seen with
Arial, Times New Roman and DejaVu Sans on Playwright WebKit 26.4 for Windows and for Linux). So
on Safari tajweed colours letters but not marks apart from their letters, and tajweed test (c) is
marked as an expected failure on WebKit. (a) and (b) hold there. Playwright's WebKit builds also
draw no Digital Khatt marks or dots at all (letters only), so the (a) and (b) WebKit runs compare
letters, not marks; real Safari draws them through CoreText.
