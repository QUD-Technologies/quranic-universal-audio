# Quran cells

For installation, renderer options, boundary-stable setup, component props,
and theming, see the [renderer consumer guide](RENDERER.md).

`@quranic-phonemizer/cells` renders the versioned native cell wire from
Quranic Phonemizer. It draws a reading and its boundary controls; it does not
contain a tajweed rule inventory or decide recitation semantics.

```ts
import { AnalysisRow, parse } from '@quranic-phonemizer/cells';
import '@quranic-phonemizer/cells/cells.css';

const { view, context } = parse(payload, defineRule, options);
```

Offline audio shards may instead store compact codec 1 and call
`parseCompact(compactPayload, defineRule, options)`. The package owns that
decoder, so hosts do not reconstruct native cells or positional ownership.

`parse()` accepts `{ analysis, cells }`, checks both document
`schema_version` values, and throws `SchemaMismatchError` when either is not
the supported version. It joins cell sound IDs to analysis tokens, resolves
silence occurrences to rule IDs, and formats the producer's word and boundary
fields for display. The result is a `CellView` plus a `CellContext`.

The producer supplies every cell, named-letter run, internal merger bridge,
group, sound span, rule placement, boundary sound, verse end, and exclusive
stop group. The package does not insert
carriers, fold marks, discover groups, propagate sound rules, or infer boundary
semantics. Its only rule-specific transforms are the configurable visual iqlab
mini-meem and the open-versus-closed tanween glyph choice.

The host supplies `defineRule(ruleId)`. A `RuleDefinition.color_var` names the
host custom property used for a rule bar, so rule colours never live in the
renderer. The stylesheet exposes `--qc-*` tokens for cell surfaces, text,
interactive state, and hover tips. Override those tokens for any light or dark
theme; package code does not inspect a theme.

Boundary-stable layouts are available separately:

```ts
import {
  buildStableLayout,
  canonicalStopSets,
} from '@quranic-phonemizer/cells/union';
```

Parse the four canonical stop-set payloads, call
`buildStableLayout(parsed.map(one => one.view))`, and pass that layout beside
the unmodified current view:

```svelte
<AnalysisRow {view} {context} {stableLayout} crossWordMergers="extend" />
```

The stable sizing plan contains canonical glyph, sound-cluster, seam, boundary,
and potential-bridge geometry. The visible cells always come from the current
native view. Without `stableLayout`, `AnalysisRow` renders that view at its
natural size, which is the simple static/offline-shard path. Cross-word merger
phonemes default to the compact boundary cell; the optional `extend` mode spans
the producer-declared letters on both words and the gap between them.

The package major version equals the phonemizer wire schema version it reads.
Package `2.x` reads `schema_version: 2`; a producer schema bump requires the
next package major.

Static audio readers render with no alternate stop plans:

```svelte
<AnalysisRow
  {view}
  {context}
  crossWordMergers="compact"
  verseFlow="inline"
  showTooltips={false}
  {hostClasses}
  {keepBoundaryWithNext}
  {wordAddon}
/>
```

The package exposes `data-qc-*` identity hooks for words, native groups,
columns, sounds, boundaries, and bridges. `groupKey()` defines a group as its
ordered native column IDs. Timing, highlighting, audio interaction, reports,
translations, and rule presentation remain host concerns. Timing hosts may pass
`keepBoundaryWithNext` to keep a recorded boundary and both adjacent words in
one symmetric, unbreakable run.
