# Renderer consumer guide

`@quranic-phonemizer/cells` is the Svelte renderer for Quranic Phonemizer's
schema-v2 native cell wire. It parses, validates, optionally provides stable
space, and draws the producer's cells. It does not infer tajweed or repair a
projection.

## Install and import

The package is released from a subtree-split tag:

```bash
npm install github:Hetchy/quranic-phonemizer-web#cells-v2.2.2
```

```ts
import {
  AnalysisRow,
  parse,
  type RendererOptions,
} from '@quranic-phonemizer/cells';
import {
  buildStableLayout,
  canonicalStopSets,
} from '@quranic-phonemizer/cells/union';
import '@quranic-phonemizer/cells/cells.css';
```

## Parse the wire

```ts
const options: RendererOptions = {
  iqlabTanween: 'mini-meem',
  iqlabNoon: 'mini-meem',
  openTanween: true,
};

const { view, context } = parse(payload, defineRule, options);
```

`parse()` checks both `analysis.schema_version` and `cells.schema_version`,
throwing `SchemaMismatchError` on a mismatch. It also joins sound IDs to their
analysis tokens and resolves silence occurrences. `defineRule(ruleId)` is a
host callback returning the rule's label, legend key, colour variable, stack
layer, and optional visual treatment.

`RuleDefinition.visual` is `underline` by default. `border` draws a full inset
ring without consuming an underline layer. `wrap` keeps the bottom underline
and adds short side segments that turn up the cell edges. The host supplies the
colour; the renderer supplies the geometry.

### Compact offline storage

Audio readers can store the renderer-visible subset with compact codec 1 and
decode it through the same parser:

```ts
import { decodeCompact, parseCompact } from '@quranic-phonemizer/cells';

const wire = decodeCompact(stored.render);
const { view, context } = parseCompact(stored.render, defineRule, options);
```

The codec uses positional native word, sound, occurrence, and post-word
boundary identities plus fixed-position tuples for columns, groups, runs, and
bridges. It omits analysis/source fields the renderer never reads. The SDK
encoder must prove those positional identities before writing; malformed or
unknown codec versions throw instead of falling back to proximity or glyph
matching. `decodeCompact()` returns the schema-v2 wire subset consumed by
`parse()`, while `parseCompact()` is the direct rendering path.

## Visual options

All options are optional. The values shown below are the defaults.

| Option | Default | Other value | Effect |
| --- | --- | --- | --- |
| `iqlabTanween` | `'mini-meem'` | `'tanween'` | Split iqlab tanween into its haraka and a mini-meem, or keep iqlab and its nasal on the tanween. |
| `iqlabNoon` | `'mini-meem'` | `'noon'` | Mute the written noon and move iqlab to a mini-meem, or keep the noon active with no mini-meem. |
| `openTanween` | `true` | `false` | Use Digital Khatt's open tanween for ikhfaa/idgham, plus unsplit iqlab; false keeps every tanween closed/stacked. |

The mini-meem modes and open tanween are the only rule-specific display
conveniences in the package. Native cells still own glyph composition, status,
sound ownership, rules, groups, and boundary semantics.

Schema 2 also carries optional flat `runs` on a word and producer-declared
word-local `bridges`. Runs add spacing between the spelled names of disjoint
letters without creating another component layer. Internal bridges render their
shared phoneme across the declared contributor and host columns; the renderer
does not recognize rule names to discover them.

## Keep boundary toggles stable

Build one immutable sizing plan from the four canonical stop plans, all parsed
with the same options. Keep every parsed view native and state-specific:

```ts
const parsed = payloads.map((payload) => parse(payload, defineRule, options));
const stableLayout = buildStableLayout(parsed.map((one) => one.view));
const current = parsed[0];
const { view, context } = current;
```

`canonicalStopSets(locations)` returns the required empty, all, even, and odd
sets. The plan sizes stable content tracks, alternate native sound clusters,
latent native seams, boundary marks, and potential merger bridges. It never
changes the current view's groups, sound ownership, rules, or column IDs.

Active and potential merger chains wrap as one unit in `AnalysisRow`.
`verseFlow="break"` starts a new run at each verse; `verseFlow="inline"`
keeps a connected cross-verse reading inline without changing its phonemes.

Cross-word merger placement is an `AnalysisRow` display option:

| Prop | Default | Other value | Effect |
| --- | --- | --- | --- |
| `crossWordMergers` | `'compact'` | `'extend'` | Keep the merger phoneme in its boundary cell, or extend it from the producer's `before_column_ids` through the word gap to its `after_column_ids`. |

`extend` changes only the visible phoneme-box geometry. The producer's bridge,
sound ownership, column IDs, rules, and stable sizing plan remain unchanged.

## Render

```svelte
<AnalysisRow
  {view}
  context={{ ...context, disabled }}
  {stableLayout}
  crossWordMergers="extend"
  verseFlow="break"
  ontoggleboundary={(boundaryId) => toggle(boundaryId)}
/>
```

`disabled` is an optional set of legend keys. `ontoggleboundary` is optional;
without it the row remains readable but its boundary controls do not change a
reading. `stableLayout` is optional too: omit it for a static/offline shard and
the current native view renders naturally with no canonical fetch. The compact
merger mode requires no runtime geometry; `extend` follows the two live target
cells with a `ResizeObserver`. `crossWordMergers` is optional and defaults to
the compact boundary cell used by earlier releases.

Static readers can omit both `stableLayout` and `ontoggleboundary`, set
`crossWordMergers="compact"`, and render the native shard directly. A boundary
without a callback is a non-clickable note. At a verse-final sakt the verse
marker wins, so a second sakt sign is not drawn.

## Host integration

`showTooltips={false}` disables the package tooltip when the host supplies its
own. `hostClasses` can add classes to visible words, groups, columns, sounds,
boundaries, and bridges without rebuilding a cell model. `wordAddon` is a
Svelte snippet receiving `(word, index)` for translation or timing content.
`keepBoundaryWithNext` is an optional host predicate for making a boundary and
its two neighbouring words one unbreakable, evenly spaced run. Audio readers
use it for recorded pauses so dynamic spacing is applied outside the complete
`word + pause + word` junction, never on only one side of the pause marker.

Every visible native entity has a stable hook:

| Entity | Hook |
| --- | --- |
| word | `data-qc-word-id` |
| group | `data-qc-group-key` |
| column | `data-qc-column-id` |
| sound | `data-qc-sound-id` |
| boundary | `data-qc-boundary-id` |
| bridge | `data-qc-bridge-id` |

`groupKey(group)` returns the documented group key: the native group's ordered
`column_ids`, stringified and joined with `:`. It never depends on glyph text,
visual proximity, or a renderer-generated ordinal. Invisible stable-layout
sizers do not expose identity hooks.

`stripBoundaryMarks(text, boundary)` is the boundary-aware Digital Khatt text
helper. It removes the extracted stop/sakt mark from a word override while
leaving the boundary cell responsible for rendering it.

## Theme and rule colours

Override the package's `--qc-*` custom properties from the host theme. Supply
rule colours through each `RuleDefinition.color_var`; the package stylesheet
never names a site-specific `--tj-*` token. This keeps the renderer independent
of both the host palette and its tajweed catalogue.

Package major versions track the wire schema: package `2.x` reads
`schema_version: 2`.
