<script lang="ts">
  import type { CellColumn, CellContext, HostClasses } from './types';
  import { badgesFor, barCountOf, barsFor, namesFor, wrapColorFor } from './rules';
  import { markGlyphFor, markRenderStyle } from './mark-render';

  let {
    column,
    context,
    hostClasses = {},
    onhover,
  }: {
    column: CellColumn;
    context: CellContext;
    hostClasses?: HostClasses;
    onhover?: (names: string, target: HTMLElement | null) => void;
  } = $props();

  const badges = $derived(badgesFor(column.rule_occurrence_ids, context));
  const names = $derived(namesFor(badges, column.silence, context));
  const bars = $derived(barsFor(badges));
  const barCount = $derived(barCountOf(badges));
  const wrapColor = $derived(wrapColorFor(badges));
  const pin = $derived(column.tier === 'below' ? 'bottom' : 'top');
</script>

<span class="dia-track boundary-dia-track">
  <span
    class="haraka-cell pin-{pin} {hostClasses.column?.(column) ?? ''}"
    class:dia-inserted={column.status === 'inserted'}
    class:dia-replaced={column.status === 'replaced'}
    class:dia-dropped={column.status === 'dropped'}
    class:named={names !== ''}
    class:rule-wrapped={wrapColor !== ''}
    data-qc-column-id={String(column.id)}
    style:--bars={barCount}
    style:--qc-rule-wrap={wrapColor}
    style:box-shadow={bars}
    role="note"
    onmouseenter={(event) => onhover?.(names, event.currentTarget)}
    onmouseleave={() => onhover?.('', null)}
  >
    <span class="g" style={markRenderStyle(column.text)}>{markGlyphFor(column.text)}</span>
  </span>
</span>
