<script lang="ts">
  import type { CellBoundary, CellContext, CellSound, HostClasses } from './types';
  import type { StableBoundaryLayout } from './union';
  import type { PhonemeBox } from './groups';
  import PhonemeCell from './PhonemeCell.svelte';
  import BoundaryMark from './BoundaryMark.svelte';
  import { waqfRenderStyle } from './waqf-render';

  /* A junction is a flex column, not a grid: its boxes cover no tracks and are
     laid out one under the other. */
  const loose = (sound: CellSound): PhonemeBox => ({
    sound,
  });

  let {
    boundary,
    context,
    stableLayout,
    showMergerBridge = true,
    hostClasses = {},
    ontoggle,
    onhover,
  }: {
    boundary: CellBoundary;
    context: CellContext;
    stableLayout?: StableBoundaryLayout;
    showMergerBridge?: boolean;
    hostClasses?: HostClasses;
    ontoggle?: (boundaryId: string | number) => void;
    onhover?: (names: string, target: HTMLElement | null) => void;
  } = $props();

  const sign = $derived(boundary.columns.find((c) => c.role === 'stop_sign') ?? null);
  const inserted = $derived(boundary.columns.filter((c) => c.role !== 'stop_sign'));
  const stopped = $derived(boundary.state === 'stop' || boundary.state === 'sakt');
  const verse = $derived(boundary.verse_end ?? null);
  const stopSign = $derived(sign?.text.replaceAll('\u06dc', '') ?? '');
  const visibleSign = $derived(stopSign || sign?.text || '');
  const toggleable = $derived(boundary.state !== 'sakt' || Boolean(stopSign));
  const interactive = $derived(Boolean(ontoggle) && toggleable);

  const label = $derived(
    boundary.state === 'sakt' && !stopSign
      ? 'Sakt here.'
      : !interactive
      ? verse
        ? `End of ayah ${verse}.`
        : stopped
          ? 'Stopped boundary.'
          : 'Joined boundary.'
      : verse
      ? stopped
        ? `End of ayah ${verse}. Click to read on.`
        : `Ayah ${verse} read into the next. Click to stop here.`
      : stopped
        ? 'Stop here. Click to join.'
        : 'Joined. Click to stop here.',
  );
</script>

{#snippet mark()}
    {#if verse}
      <span class="verse-glyph">&#x06DD;{verse}</span>
    {:else if visibleSign}
      <span class="pause-waqf" style={waqfRenderStyle(visibleSign)}>{visibleSign}</span>
    {:else}
      <span class="pause-icon" aria-hidden="true"></span>
    {/if}
{/snippet}

<div
  class="boundary-tile {hostClasses.boundary?.(boundary) ?? ''}"
  class:verse-tile={verse}
  data-qc-boundary-id={String(boundary.boundary_id)}
>
  {#if interactive}
    <button
      type="button"
      class="pause-bridge"
      class:stopped
      class:verse-mark={verse}
      aria-label={label}
      aria-pressed={stopped}
      onclick={() => ontoggle?.(boundary.boundary_id)}
    >
      {@render mark()}
    </button>
  {:else}
    <span
      class="pause-bridge static"
      class:stopped
      class:verse-mark={verse}
      role="note"
      aria-label={label}
    >
      {@render mark()}
    </span>
  {/if}

  <div class="boundary-stack">
    {#each stableLayout?.variants ?? [] as variant, variantIndex (variantIndex)}
      <div class="boundary-content boundary-layout-sizer" aria-hidden="true">
        {#each variant.bridges as bridge (bridge.merger_id)}
          <span class="mega-phoneme">{bridge.sound.text}</span>
        {/each}
        {#each variant.columns.filter((column) => column.role !== 'stop_sign') as column (column.id)}
          {@const sizingSounds = variant.sounds.filter((sound) => sound.column_ids.includes(column.id))}
          <span class="boundary-insert-sizer" class:mark-bridge={column.tier !== 'main'}>
            <span class={column.tier === 'main' ? 'mega-letter' : 'dia-track'}>{column.text}</span>
            {#each sizingSounds as sound (sound.sound_id)}
              <span class="mega-phoneme">{sound.text}</span>
            {/each}
          </span>
        {/each}
      </div>
    {/each}

    <div class="boundary-content">
      {#if showMergerBridge}
        {#each boundary.bridges as bridge (bridge.merger_id)}
          <div
            class="crossword-bridge {hostClasses.bridge?.(bridge) ?? ''}"
            data-qc-bridge-id={String(bridge.merger_id)}
          >
            <PhonemeCell box={loose(bridge.sound)} {context} {hostClasses} {onhover} />
          </div>
        {/each}
      {/if}

      {#each inserted as column (column.id)}
        {@const sounds = boundary.sounds.filter((s) => s.column_ids.includes(column.id))}
        <div class="crossword-bridge borderless" class:mark-bridge={column.tier !== 'main'}>
          <BoundaryMark {column} {context} {hostClasses} {onhover} />
          {#each sounds as sound (sound.sound_id)}
            <PhonemeCell box={loose(sound)} {context} {hostClasses} {onhover} />
          {/each}
        </div>
      {/each}
    </div>
  </div>
</div>
