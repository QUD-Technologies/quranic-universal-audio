<script lang="ts">
  import type { CellBridge, CellContext, HostClasses } from './types';
  import type { PhonemeBox } from './groups';
  import PhonemeCell from './PhonemeCell.svelte';

  let {
    bridge,
    context,
    hostClasses = {},
    onhover,
  }: {
    bridge: CellBridge;
    context: CellContext;
    hostClasses?: HostClasses;
    onhover?: (names: string, target: HTMLElement | null) => void;
  } = $props();

  const box = $derived<PhonemeBox>({ sound: bridge.sound });
  let root = $state<HTMLElement | null>(null);
  let ready = $state(false);

  const byColumnIds = (run: HTMLElement, ids: Set<string>) =>
    [...run.querySelectorAll<HTMLElement>('[data-qc-column-id]')]
      .filter((element) => ids.has(element.dataset.qcColumnId ?? ''));

  $effect(() => {
    if (!root) return;
    const run = root.closest<HTMLElement>('.word-run');
    if (!run) return;
    const ids = new Set(
      [...bridge.before_column_ids, ...bridge.after_column_ids].map(String),
    );
    const cells = byColumnIds(run, ids);
    const nativeSound = [...run.querySelectorAll<HTMLElement>('[data-qc-sound-id]')]
      .filter((element) =>
        !root!.contains(element)
        && element.dataset.qcSoundId === String(bridge.sound.sound_id)
      );
    const rows = [...new Set(cells.map((cell) =>
      cell.closest('.mega-block')?.querySelector<HTMLElement>('.visible-grid .mega-phoneme')
    ).filter((row): row is HTMLElement => Boolean(row)))];
    if (cells.length !== ids.size || rows.length === 0) return;

    nativeSound.forEach((element) => element.classList.add('qc-bridge-replaced'));
    let frame = 0;
    const place = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const runRect = run.getBoundingClientRect();
        const cellRects = cells.map((cell) => cell.getBoundingClientRect());
        const rowRects = rows.map((row) => row.getBoundingClientRect());
        const left = Math.min(...cellRects.map((rect) => rect.left));
        const right = Math.max(...cellRects.map((rect) => rect.right));
        const top = Math.min(...rowRects.map((rect) => rect.top));
        const bottom = Math.max(...rowRects.map((rect) => rect.bottom));
        root!.style.left = `${left - runRect.left}px`;
        root!.style.top = `${top - runRect.top}px`;
        root!.style.width = `${right - left}px`;
        root!.style.height = `${bottom - top}px`;
        ready = true;
      });
    };
    const observer = new ResizeObserver(place);
    [run, ...cells, ...rows].forEach((element) => observer.observe(element));
    place();
    return () => {
      ready = false;
      nativeSound.forEach((element) => element.classList.remove('qc-bridge-replaced'));
      cancelAnimationFrame(frame);
      observer.disconnect();
    };
  });
</script>

<div
  class="extended-crossword-bridge {hostClasses.bridge?.(bridge) ?? ''}"
  class:ready
  data-qc-bridge-id={String(bridge.merger_id)}
  data-qc-before={bridge.before_column_ids.map(String).join(' ')}
  data-qc-after={bridge.after_column_ids.map(String).join(' ')}
  bind:this={root}
>
  <PhonemeCell {box} {context} {hostClasses} {onhover} />
</div>

<style>
  .extended-crossword-bridge {
    position: absolute;
    z-index: 2;
    display: grid;
    visibility: hidden;
    pointer-events: none;
  }

  .extended-crossword-bridge.ready {
    visibility: visible;
  }

  .extended-crossword-bridge :global(.mega-phoneme) {
    box-sizing: border-box;
    inline-size: 100%;
    block-size: 100%;
    pointer-events: auto;
  }

  /* The bridge replaces only its own native sound. Independent vowels and
     other phonemes may share its contributor columns and must remain visible. */
  :global(.word-run .visible-grid .mega-phoneme) {
    z-index: 3;
  }

  :global(.word-run .visible-grid .mega-phoneme.qc-bridge-replaced) {
    visibility: hidden;
  }
</style>
