<script lang="ts">
  import type { CellContext, HostClasses } from './types';
  import type { GroupColumn } from './groups';
  import { isSilentColumn, occurrencesOn } from './groups';
  import { badgesFor, barCountOf, barsFor, namesFor, wrapColorFor } from './rules';
  import { markGlyphFor, markRenderStyle } from './mark-render';

  let {
    col,
    context,
    hostClasses = {},
    onhover,
  }: {
    col: GroupColumn;
    context: CellContext;
    hostClasses?: HostClasses;
    onhover?: (names: string, target: HTMLElement | null) => void;
  } = $props();

  const badges = $derived(badgesFor(occurrencesOn(col.column), context));
  const names = $derived(namesFor(badges, col.column.silence, context));
  const bars = $derived(barsFor(badges));
  const barCount = $derived(barCountOf(badges));
  const wrapColor = $derived(wrapColorFor(badges));
  const silent = $derived(isSilentColumn(col.column));
</script>

{#if col.size === 'full'}
  <span
      class="mega-letter {hostClasses.column?.(col.column) ?? ''}"
      class:silent
      class:named={names !== ''}
      class:rule-wrapped={wrapColor !== ''}
      class:implicit={col.column.status === 'inserted' && col.column.source_unit_ids.length === 0}
      class:dia-inserted={col.column.status === 'inserted'}
      class:dia-replaced={col.column.status === 'replaced'}
      class:dia-dropped={col.column.status === 'dropped'}
      data-qc-column-id={String(col.column.id)}
      style:grid-column="{col.at + 1} / span {col.span}"
      style:--seam-capacity={col.seamCapacity}
      style:--bars={barCount}
      style:--qc-rule-wrap={wrapColor}
      style:box-shadow={bars}
      role="note"
      onmouseenter={(event) => onhover?.(names, event.currentTarget)}
      onmouseleave={() => onhover?.('', null)}
    >
      <span class="cell-ink">{col.column.text}</span>
  </span>
{:else}
  <span
    class="dia-track {hostClasses.column?.(col.column) ?? ''}"
    data-qc-column-id={String(col.column.id)}
    style:grid-column="{col.at + 1} / span {col.span}"
    style:--seam-capacity={col.seamCapacity}
  >
      <span
        class="haraka-cell pin-{col.pin}"
        class:dia-inserted={col.column.status === 'inserted'}
        class:dia-replaced={col.column.status === 'replaced'}
        class:dia-dropped={col.column.status === 'dropped'}
        class:named={names !== ''}
        class:rule-wrapped={wrapColor !== ''}
        style:--bars={barCount}
        style:--qc-rule-wrap={wrapColor}
        style:box-shadow={bars}
        role="note"
        onmouseenter={(event) => onhover?.(names, event.currentTarget)}
        onmouseleave={() => onhover?.('', null)}
      >
        <span class="g" style={markRenderStyle(col.column.text)}>{markGlyphFor(col.column.text)}</span>
      </span>
  </span>
{/if}
