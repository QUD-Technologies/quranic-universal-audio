<script lang="ts">
  import type { CellContext, HostClasses } from './types';
  import type { PhonemeBox } from './groups';
  import { badgesFor, barCountOf, barsFor, namesFor, wrapColorFor } from './rules';

  let {
    box,
    context,
    hostClasses = {},
    exposeIdentity = true,
    onhover,
  }: {
    box: PhonemeBox;
    context: CellContext;
    hostClasses?: HostClasses;
    exposeIdentity?: boolean;
    onhover?: (names: string, target: HTMLElement | null) => void;
  } = $props();

  const sound = $derived(box.sound);
  const badges = $derived(badgesFor(sound.rule_occurrence_ids, context));
  const names = $derived(namesFor(badges, null, context));
  const wrapColor = $derived(wrapColorFor(badges));

  /* Only the length marks detach. The emphatic belongs to the consonant symbol
     and stays in the base. */
  const split = (phone: string) => {
    const match = /^(.*?)([ːː:]*)$/u.exec(phone);
    return { base: match?.[1] || phone, mod: match?.[2] ?? '' };
  };
</script>

{#snippet ink(text: string)}
  {@const parts = split(text)}
  <span class="ph-ink"
    ><span class="ph-base">{parts.base}</span>{#if parts.mod}<sup class="ph-mod">{parts.mod}</sup
      >{/if}</span
  >
{/snippet}

<span
    class="mega-phoneme {exposeIdentity ? hostClasses.sound?.(sound) ?? '' : ''}"
    data-qc-sound-id={exposeIdentity ? String(sound.sound_id) : undefined}
    class:named={names !== ''}
    class:rule-wrapped={wrapColor !== ''}
    style:--bars={barCountOf(badges)}
    style:--qc-rule-wrap={wrapColor}
    style:box-shadow={barsFor(badges)}
    role="note"
    onmouseenter={(event) => onhover?.(names, event.currentTarget)}
    onmouseleave={() => onhover?.('', null)}
  >
    {@render ink(sound.text)}
</span>
