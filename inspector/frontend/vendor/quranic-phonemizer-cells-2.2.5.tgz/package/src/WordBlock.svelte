<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { CellContext, CellWord, HostClasses } from './types';
  import type { StableWordLayout } from './union';
  import { layoutWord } from './groups';
  import GraphemeCell from './GraphemeCell.svelte';
  import PhonemeCell from './PhonemeCell.svelte';
  import { groupKey } from './identity';

  let {
    word,
    context,
    state = 'natural',
    stableLayout,
    index = 0,
    hostClasses = {},
    addon,
    onhover,
  }: {
    word: CellWord;
    context: CellContext;
    state?: string;
    stableLayout?: StableWordLayout;
    index?: number;
    hostClasses?: HostClasses;
    addon?: Snippet<[CellWord, number]>;
    onhover?: (names: string, target: HTMLElement | null) => void;
  } = $props();

  const layout = $derived(layoutWord(word, state, stableLayout));
</script>

<div
  class="mega-block {hostClasses.word?.(word, index) ?? ''}"
  data-location={word.location}
  data-qc-word-id={String(word.word_id)}
>
  {#if addon}
    {@render addon(word, index)}
  {/if}
  <div class="mega-word">{word.display_text}</div>

  <div class="mega-grid" dir="rtl" style:grid-template-columns={layout.template}>
    {#each layout.glyphs as glyph (glyph.at + ':' + glyph.column.tier + ':' + glyph.column.text)}
      {#if glyph.column.tier === 'main'}
        <span
          class="mega-letter layout-sizer glyph-sizer"
          style:grid-column={glyph.at + 1}
          style:--seam-capacity={glyph.seamCapacity}
          ><span class="cell-ink">{glyph.column.text}</span></span
        >
      {:else}
        <span
          class="dia-track layout-sizer glyph-sizer"
          style:grid-column={glyph.at + 1}
          style:--seam-capacity={glyph.seamCapacity}
        ></span>
      {/if}
    {/each}
    {#each layout.sounds as sound (sound.at + ':' + sound.span + ':' + sound.sounds.map((one) => one.text).join('|'))}
      <span
        class="phoneme-cluster layout-sizer sound-sizer"
        style:grid-column="{sound.at + 1} / span {sound.span}"
        style:--bcols={Math.max(sound.sounds.length, 1)}
        style:--seam-capacity={sound.seamCapacity}
      >
        {#each sound.sounds as box (box.sound_id)}
          <PhonemeCell box={{ sound: box }} {context} exposeIdentity={false} />
        {/each}
      </span>
    {/each}

    <div class="visible-grid">
      {#each layout.groups as group (group.key)}
        <div
          class="cell-group {hostClasses.group?.(group.raw, layout.groups.indexOf(group)) ?? ''}"
          data-qc-group-key={groupKey(group.raw)}
          class:vowel={group.kind === 'vowel'}
          style:grid-column="{group.at + 1} / span {group.span}"
          style:--native-gaps={group.gapAfter}
          style:--run-gaps={group.runGapAfter}
        >
          {#each group.cols as col (col.column.id)}
            <GraphemeCell {col} {context} {hostClasses} {onhover} />
          {/each}

          {#each group.spans as span (span)}
            <span
              class="phoneme-cluster"
              class:fill={span.boxes.length <= 1}
              style:grid-column="{span.at + 1} / span {span.span}"
              style:--bcols={Math.max(span.boxes.length, 1)}
            >
              {#if span.boxes.length === 0}
                <span class="mega-phoneme blank" aria-hidden="true"></span>
              {/if}
              {#each span.boxes as box (box.sound.sound_id)}
                <PhonemeCell {box} {context} {hostClasses} {onhover} />
              {/each}
            </span>
          {/each}
        </div>
      {/each}

      {#each layout.spans as span (span.owner + ':' + span.at + ':' + span.span)}
        <span
          class="phoneme-cluster word-span"
          class:fill={span.boxes.length <= 1}
          style:grid-column="{span.at + 1} / span {span.span}"
          style:--bcols={Math.max(span.boxes.length, 1)}
          style:--span-native-gaps={span.inlineEndGap}
          style:--span-run-gaps={span.inlineEndRunGap}
        >
          {#each span.boxes as box (box.sound.sound_id)}
            <PhonemeCell {box} {context} {hostClasses} {onhover} />
          {/each}
        </span>
      {/each}
    </div>
  </div>
</div>
