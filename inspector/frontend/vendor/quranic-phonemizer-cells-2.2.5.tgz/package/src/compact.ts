import type {
  CellColumn,
  CellGroup,
  CellRun,
} from './types';
import type { RendererOptions } from './visual';
import {
  parse,
  type DefineRule,
  type ParsedCells,
  type WirePayload,
} from './wire';

export const COMPACT_CODEC_VERSION = 1;

export class CompactSchemaMismatchError extends Error {
  constructor(received: unknown) {
    super(`compact codec version ${String(received)}, expected ${COMPACT_CODEC_VERSION}`);
    this.name = 'CompactSchemaMismatchError';
  }
}

type CompactId = number;
type CompactSound = [CompactId, CompactId[], CompactId[]];
type CompactBridge = [CompactId, CompactId[], CompactId[], CompactSound];
type CompactGroup = [CompactId, number, CompactId[], CompactId[]];
type CompactRun = [CompactId, CompactId, CompactId[]];
type CompactSilence = number | null;

/** Fixed-position column tuple. See RENDERER.md for the storage contract. */
export type CompactColumn = [
  CompactId,
  number,
  string,
  CompactId[],
  CompactId[],
  number,
  CompactId | null,
  number,
  CompactId | null,
  number | null,
  CompactId[],
  CompactId[],
  CompactId[],
  CompactSilence,
];

export type CompactWord = [
  string,
  string,
  CompactColumn[],
  CompactSound[],
  CompactGroup[],
  CompactRun[],
  CompactBridge[],
];

export type CompactBoundary = [
  number,
  CompactColumn[],
  CompactSound[],
  CompactBridge[],
  number | null,
  number | null,
];

export interface CompactCellPayload {
  v: number;
  /** Reading ref, canonical digest and full native-document digest. */
  m: [string, string, string];
  /** Sound tokens indexed by native sound id. */
  p: string[];
  /** Rule ids indexed by native occurrence id. */
  r: string[];
  /** Words indexed by native word id. */
  w: CompactWord[];
  /** Post-word boundaries; item i has native boundary id i + 1. */
  b: CompactBoundary[];
}

const ROLES: CellColumn['role'][] = [
  'letter', 'haraka', 'sukun', 'tanween', 'madd', 'stop_sign', 'gap',
];
const TIERS: CellColumn['tier'][] = ['main', 'above', 'below'];
const STATUSES: CellColumn['status'][] = [
  'present', 'inserted', 'replaced', 'dropped', 'gap',
];
const SIDES: NonNullable<CellColumn['side']>[] = ['before', 'after'];
const STATES = ['start', 'join', 'sakt', 'stop'] as const;
const GROUP_KINDS: CellGroup['kind'][] = ['base', 'vowel'];

function at<T>(values: readonly T[], index: number, label: string): T {
  const value = values[index];
  if (value === undefined) throw new Error(`Invalid compact ${label} code ${index}`);
  return value;
}

function silenceOf(
  raw: CompactSilence,
): number | 'orthographic_silence' | 'variant_silence' | null {
  if (raw === -1) return 'orthographic_silence';
  if (raw === -2) return 'variant_silence';
  return raw;
}

function columnOf(raw: CompactColumn) {
  return {
    id: raw[0], role: at(ROLES, raw[1], 'role'), text: raw[2],
    source_character_ids: [], source_unit_ids: raw[3], slot_ids: raw[4],
    tier: at(TIERS, raw[5], 'tier'), attached_to_column_id: raw[6],
    status: at(STATUSES, raw[7], 'status'), variant_id: null, variant_choice: null,
    anchor_unit_id: raw[8], side: raw[9] === null ? null : at(SIDES, raw[9], 'side'),
    owned_sound_ids: raw[10], presented_sound_ids: raw[11],
    rule_occurrence_ids: raw[12], silence: silenceOf(raw[13]),
  };
}

const soundOf = (raw: CompactSound) => ({
  sound_id: raw[0], column_ids: raw[1], rule_occurrence_ids: raw[2],
});

const bridgeOf = (raw: CompactBridge) => ({
  merger_id: raw[0], before_column_ids: raw[1], after_column_ids: raw[2],
  sound: soundOf(raw[3]),
});

const groupOf = (raw: CompactGroup): CellGroup => ({
  key: raw[0], kind: at(GROUP_KINDS, raw[1], 'group kind'),
  column_ids: raw[2], sound_ids: raw[3],
});

const runOf = (raw: CompactRun): CellRun => ({
  id: raw[0], source_unit_id: raw[1], column_ids: raw[2],
});

function wordOf(raw: CompactWord, wordId: number) {
  return {
    word_id: wordId,
    columns: raw[2].map(columnOf), sounds: raw[3].map(soundOf),
    groups: raw[4].map(groupOf), runs: raw[5].map(runOf),
    bridges: raw[6].map(bridgeOf),
  };
}

function boundaryOf(raw: CompactBoundary, index: number) {
  return {
    boundary_id: index + 1,
    columns: raw[1].map(columnOf), sounds: raw[2].map(soundOf),
    bridges: raw[3].map(bridgeOf), state: at(STATES, raw[0], 'boundary state'),
    verse_end: raw[4], exclusive_group: raw[5],
  };
}

function soundOwners(payload: CompactCellPayload): Map<CompactId, number> {
  const owners = new Map<CompactId, number>();
  payload.w.forEach((word, wordId) => {
    word[3].forEach((sound) => owners.set(sound[0], wordId));
  });
  return owners;
}

/** Expand the storage codec into the schema-v2 subset consumed by parse(). */
export function decodeCompact(payload: CompactCellPayload): WirePayload {
  if (payload?.v !== COMPACT_CODEC_VERSION) {
    throw new CompactSchemaMismatchError(payload?.v);
  }
  if (payload.w.length !== payload.b.length) {
    throw new Error('Compact word and boundary counts differ');
  }
  const owners = soundOwners(payload);
  const words = payload.w.map((raw, id) => ({
    id, ref: raw[0], text: raw[1], before_boundary_id: id,
    after_boundary_id: id + 1, sound_ids: raw[3].map((sound) => sound[0]),
  }));
  return {
    analysis: {
      schema_version: 2,
      result: {
        words,
        boundaries: [],
        sounds: payload.p.map((token, id) => ({
          id, order: id, token, word_id: owners.get(id) ?? 0, rule_occurrence_ids: [],
        })),
        rule_occurrences: payload.r.map((rule_id, id) => ({ id, rule_id })),
      },
    },
    cells: {
      schema_version: 2,
      cell_view: {
        words: payload.w.map(wordOf),
        boundaries: payload.b.map(boundaryOf),
      },
    },
  };
}

/** Decode and render a compact storage payload through the normal parser. */
export function parseCompact(
  payload: CompactCellPayload,
  defineRule: DefineRule,
  options: RendererOptions = {},
): ParsedCells {
  return parse(decodeCompact(payload), defineRule, options);
}

export type {
  CompactBridge,
  CompactGroup,
  CompactRun,
  CompactSound,
};
