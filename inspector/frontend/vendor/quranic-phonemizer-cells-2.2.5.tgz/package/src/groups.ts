import type { CellColumn, CellId, CellWord } from './types';
import {
  collectSeams, groupSoundConstraints,
  LayoutInvariantError,
  slotKeys,
  type StableGroupVariant,
  type StableSeam,
  type StableWordLayout,
  type StableWordVariant,
} from './union';
import { materializeDormantIqlab } from './visual';
import { crossGroupSpans, localSoundSpans } from './sound-layout';
import type {
  LayoutGroup,
  PhonemeSpan,
  TrackSpan,
  WordLayout,
  WordPhonemeSpan,
} from './layout-types';
export type {
  GlyphSizer,
  GroupColumn,
  GroupKind,
  LayoutGroup,
  PhonemeBox,
  PhonemeSpan,
  SoundSizer,
  TrackSpan,
  WordPhonemeSpan,
  WordLayout,
} from './layout-types';

const isMain = (column: CellColumn) => column.tier === 'main';

export const isSilentColumn = (column: CellColumn): boolean =>
  column.silence !== null
  || (column.owned_sound_ids.length === 0 && column.presented_sound_ids.length === 0);

function shapeOf(column: CellColumn) {
  if (isMain(column)) return { size: 'full' as const, pin: null };
  return {
    size: 'small' as const,
    pin: column.tier === 'below' ? ('bottom' as const) : ('top' as const),
  };
}

function currentVariant(word: CellWord, state: string): StableWordVariant {
  const rawKeys = slotKeys(word);
  const keyById = new Map(word.columns.map((column, at) => [column.id, rawKeys[at]!]));
  const grouped = word.groups.flatMap((group) =>
    group.column_ids.map((id) => keyById.get(id)!)
  );
  const claimed = new Set(grouped);
  const keys = [...grouped, ...rawKeys.filter((key) => !claimed.has(key))];
  const groups = word.groups.map((group): StableGroupVariant => ({
    host: keyById.get(group.key) ?? missing(word, state, `group host ${String(group.key)}`),
    kind: group.kind,
    slots: group.column_ids.map((id) =>
      keyById.get(id) ?? missing(word, state, `group column ${String(id)}`)
    ),
    soundIds: [...group.sound_ids],
  }));
  return { state, word, keys, keyById, groups };
}

function missing(word: CellWord, state: string, detail: string): never {
  throw new LayoutInvariantError(`${word.location} ${state}: missing ${detail}`);
}

interface Tracks {
  at: Map<string, number>;
  count: number;
}

function tracksOf(plan: StableWordLayout): Tracks {
  return {
    at: new Map(plan.slots.map((slot, at) => [slot, at])),
    count: plan.slots.length,
  };
}

const groupOf = (variant: StableWordVariant, slot: string) =>
  variant.groups.find((group) => group.slots.includes(slot));

function seamsByCut(seams: StableSeam[]): StableSeam[][] {
  const grouped = new Map<number, StableSeam[]>();
  for (const seam of seams) {
    const cut = grouped.get(seam.after) ?? [];
    cut.push(seam);
    grouped.set(seam.after, cut);
  }
  return [...grouped.values()];
}

function seamIsActive(current: StableWordVariant, seam: StableSeam): boolean {
  const left = groupOf(current, seam.left);
  const right = groupOf(current, seam.right);
  return Boolean(left && right && left !== right);
}

function intersection(groups: StableGroupVariant[]): Set<string> {
  if (groups.length === 0) return new Set();
  return new Set(groups[0]!.slots.filter((slot) =>
    groups.slice(1).every((group) => group.slots.includes(slot))
  ));
}

function absentAbsorber(
  plan: StableWordLayout, current: StableWordVariant, slot: string,
): string {
  const donors = [...plan.variants.values()].flatMap((variant) => {
    const group = groupOf(variant, slot);
    return group ? [group] : [];
  });
  const present = new Set(current.keys);
  const hosts = [...new Set(donors.map((group) => group.host))]
    .filter((host) => present.has(host));
  if (hosts.length === 1) return hosts[0]!;
  const candidates = [...intersection(donors)].filter((key) => present.has(key));
  if (candidates.length !== 1) throw new LayoutInvariantError(
    `${plan.location} ${current.state}: slot ${slot} has ${candidates.length} absorbers `
      + `[${candidates.join(',')}], donors ${donors.map((group) => group.slots.join('+')).join(';')}`,
  );
  return candidates[0]!;
}

function seamAbsorber(
  plan: StableWordLayout, current: StableWordVariant, seam: StableSeam,
): string {
  const position = new Map(plan.slots.map((slot, at) => [slot, at]));
  const present = new Set(current.keys);
  const adjacentMissing = [seam.left, seam.right]
    .filter((slot) => slot !== undefined && !present.has(slot))
    .map((slot) => absentAbsorber(plan, current, slot));
  const adjacent = [...new Set(adjacentMissing)];
  if (adjacent.length === 1) return adjacent[0]!;
  const crossing = current.groups.filter((group) => {
    const places = group.slots.map((slot) => position.get(slot) ?? -1);
    return Math.min(...places) <= seam.after && Math.max(...places) > seam.after;
  });
  const active = [...plan.variants.values()].filter((variant) =>
    seam.activeStates.has(variant.state)
  );
  const candidates = crossing.flatMap((group) => active.flatMap((variant) =>
    group.slots.flatMap((slot) => {
      const donor = groupOf(variant, slot);
      return donor && donor.host !== group.host && present.has(donor.host) ? [donor.host] : [];
    })
  ));
  const movingMembers = crossing.length === 1
    ? [seam.left, seam.right].filter((slot) => {
        const currentGroup = crossing[0]!;
        if (slot === currentGroup.host || !currentGroup.slots.includes(slot)) return false;
        const signature = `${currentGroup.host}|${currentGroup.slots.join('+')}`;
        return active.some((variant) => {
          const donor = groupOf(variant, slot);
          return donor && `${donor.host}|${donor.slots.join('+')}` !== signature;
        });
      })
    : [];
  /* A changed native host is the moving member. When the host stays fixed,
     the one non-host seam endpoint whose group signature changes is. */
  const changedHosts = [...new Set(candidates)];
  const unique = changedHosts.length > 0 ? changedHosts : [...new Set(movingMembers)];
  if (unique.length !== 1) throw new LayoutInvariantError(
    `${plan.location} ${current.state}: seam ${seam.id} has ${unique.length} absorbers `
      + `[${unique.join(',')}], crossing ${crossing.map((group) => `${group.host}:${group.slots.join('+')}`).join(';')}`,
  );
  return unique[0]!;
}

function capacities(
  plan: StableWordLayout, current: StableWordVariant, tracks: Tracks,
): {
  owned: Map<string, number[]>;
  seamCapacity: Map<string, number>;
  seams: WordLayout['seams'];
} {
  const owned = new Map(current.keys.map((slot) => [slot, [tracks.at.get(slot)!]]));
  const seamCapacity = new Map(current.keys.map((slot) => [slot, 0]));
  const seams: WordLayout['seams'] = [];
  for (const slot of plan.slots) {
    if (owned.has(slot)) continue;
    owned.get(absentAbsorber(plan, current, slot))!.push(tracks.at.get(slot)!);
  }
  for (const cut of seamsByCut(plan.seams)) {
    const active = cut.filter((seam) => seamIsActive(current, seam));
    if (active.length > 0) {
      cut.forEach((seam) => seams.push({ id: seam.id, active: true, absorber: null }));
      continue;
    }
    const absorbers = [...new Set(cut.map((seam) => seamAbsorber(plan, current, seam)))];
    if (absorbers.length !== 1) throw new LayoutInvariantError(
      `${plan.location} ${current.state}: seam cut ${cut[0]!.after} has `
        + `${absorbers.length} absorbers [${absorbers.join(',')}]`,
    );
    const absorber = absorbers[0]!;
    seamCapacity.set(absorber, seamCapacity.get(absorber)! + 1);
    cut.forEach((seam) => seams.push({ id: seam.id, active: false, absorber }));
  }
  return { owned, seamCapacity, seams };
}

function rangeOf(values: number[], where: string): TrackSpan {
  const sorted = [...new Set(values)].sort((a, b) => a - b);
  if (sorted.length === 0) throw new LayoutInvariantError(`${where}: empty track range`);
  if (sorted.at(-1)! - sorted[0]! + 1 !== sorted.length) throw new LayoutInvariantError(
    `${where}: non-contiguous tracks ${sorted.join(',')}`,
  );
  return { at: sorted[0]!, span: sorted.length };
}

const runOf = (word: CellWord, group: CellWord['groups'][number]): number =>
  word.runs.findIndex((run) =>
    group.column_ids.some((id) => run.column_ids.includes(id))
  );

function groupsOfVariant(
  word: CellWord,
  variant: StableWordVariant,
  owned: Map<string, number[]>,
  seamCapacity: Map<string, number>,
  plan: StableWordLayout,
): LayoutGroup[] {
  const columns = new Map(word.columns.map((column) => [column.id, column]));
  const cellRanges = new Map<string, TrackSpan>();
  owned.forEach((value, slot) => cellRanges.set(
    slot, rangeOf(value, `${word.location} ${variant.state} slot ${slot}`),
  ));
  return word.groups.map((raw, index) => {
    const stable = variant.groups[index]
      ?? missing(word, variant.state, `stable group ${String(raw.key)}`);
    const groupTracks = stable.slots.flatMap((slot) => {
      const range = cellRanges.get(slot)!;
      return Array.from({ length: range.span }, (_, at) => range.at + at);
    });
    const range = rangeOf(
      groupTracks,
      `${word.location} ${variant.state} group ${String(raw.key)} `
        + `${stable.slots.join('+')} (${groupTracks.join(',')})`,
    );
    const cols = raw.column_ids.map((id) => {
      const column = columns.get(id) ?? missing(word, variant.state, `column ${String(id)}`);
      const slot = variant.keyById.get(id)!;
      const own = cellRanges.get(slot)!;
      return {
        slot,
        column,
        ...shapeOf(column),
        at: own.at - range.at,
        span: own.span,
        seamCapacity: seamCapacity.get(slot) ?? 0,
      };
    });
    const spans = localSoundSpans(word, raw, variant, cellRanges, range.at);
    const covered = new Set(spans.flatMap((span) =>
      Array.from({ length: span.span }, (_, at) => span.at + at)
    ));
    for (const col of cols) {
      const positions = Array.from({ length: col.span }, (_, at) => col.at + at);
      if (positions.some((at) => covered.has(at))) continue;
      spans.push({ at: col.at, span: col.span, boxes: [] });
    }
    return {
      key: raw.key,
      raw,
      kind: raw.kind,
      ...range,
      cols,
      spans,
      gapAfter: Number(plan.seams.some((seam) =>
        seamIsActive(variant, seam)
        && stable.slots.includes(seam.left)
        && variant.groups.some((next) => next !== stable && next.slots.includes(seam.right))
      )),
      runGapAfter: Number(
        word.groups[index + 1] !== undefined
        && runOf(word, raw) !== runOf(word, word.groups[index + 1]!),
      ),
    };
  });
}

function seamBudgets(
  plan: StableWordLayout,
  current: StableWordVariant,
  inactive: Map<string, number>,
): Map<string, number> {
  const budgets = new Map(plan.slots.map((slot) => [slot, 0]));
  inactive.forEach((count, slot) => budgets.set(slot, count));
  for (const cut of seamsByCut(plan.seams)) {
    const active = cut.filter((seam) => seamIsActive(current, seam));
    if (active.length === 0) continue;
    const owner = plan.slots[cut[0]!.after]
      ?? missing(current.word, current.state, `seam owner at ${cut[0]!.after}`);
    budgets.set(owner, (budgets.get(owner) ?? 0) + 1);
  }
  return budgets;
}

function soundSizingConstraints(plan: StableWordLayout, tracks: Tracks) {
  const constraints = new Map<string, Omit<WordLayout['sounds'][number], 'seamCapacity'>>();
  const add = (span: PhonemeSpan) => {
    if (span.boxes.length === 0) return;
    const sounds = span.boxes.map((box) => box.sound);
    const signature = `${span.at}|${span.span}|${sounds.map((sound) => sound.text).join('|')}`;
    constraints.set(signature, { at: span.at, span: span.span, sounds });
  };
  for (const source of plan.variants.values()) {
    const word = materializeDormantIqlab(source.word, plan);
    const variant = currentVariant(word, source.state);
    const capacity = capacities(plan, variant, tracks);
    const groups = groupsOfVariant(
      word, variant, capacity.owned, capacity.seamCapacity, plan,
    );
    for (const group of groups) {
      for (const span of group.spans) {
        add({ ...span, at: group.at + span.at });
      }
    }
    crossGroupSpans(word, groups).forEach(add);
  }
  return [...constraints.values()];
}

function sizers(
  plan: StableWordLayout,
  current: StableWordVariant,
  inactive: Map<string, number>,
  tracks: Tracks,
) {
  const budgets = seamBudgets(plan, current, inactive);
  const glyphs = plan.glyphs.map(({ slot, column }) => ({
    at: tracks.at.get(slot)!,
    column,
    seamCapacity: budgets.get(slot) ?? 0,
  }));
  const sounds = soundSizingConstraints(plan, tracks).map((constraint) => ({
    ...constraint,
    seamCapacity: plan.slots.slice(constraint.at, constraint.at + constraint.span)
      .reduce((total, slot) => total + (budgets.get(slot) ?? 0), 0),
  }));
  return { glyphs, sounds };
}

function naturalPlan(word: CellWord, state: string): StableWordLayout {
  const variant = currentVariant(word, state);
  return {
    location: word.location,
    slots: variant.keys,
    seams: collectSeams(variant.keys, [variant]),
    variants: new Map([[state, variant]]),
    glyphs: word.columns.map((column) => ({ slot: variant.keyById.get(column.id)!, column })),
    sounds: groupSoundConstraints(variant),
  };
}

export function layoutWord(
  word: CellWord, state = 'natural', stable?: StableWordLayout,
): WordLayout {
  const plan = stable ?? naturalPlan(word, state);
  const rendered = stable ? materializeDormantIqlab(word, plan) : word;
  const variant = currentVariant(rendered, state);
  const unknown = variant.keys.filter((slot) => !plan.slots.includes(slot));
  if (unknown.length > 0) throw new LayoutInvariantError(
    `${word.location} ${state}: unknown slots ${unknown.join(',')}`,
  );
  const tracks = tracksOf(plan);
  const capacity = capacities(plan, variant, tracks);
  const groups = groupsOfVariant(
    rendered, variant, capacity.owned, capacity.seamCapacity, plan,
  );
  const spans = crossGroupSpans(rendered, groups);
  const sizing = sizers(plan, variant, capacity.seamCapacity, tracks);
  return {
    trackCount: tracks.count,
    template: `repeat(${tracks.count}, max-content)`,
    groups,
    spans,
    ...sizing,
    seams: capacity.seams,
    descriptor: JSON.stringify({
      tracks: tracks.count,
      glyphs: sizing.glyphs.map((one) => [
        one.at, one.column.tier, one.column.text,
      ]),
      sounds: sizing.sounds.map((one) => [
        one.at, one.span, one.sounds.map((sound) => sound.text),
      ]),
      seams: seamsByCut(plan.seams).length,
    }),
  };
}

export const groupsOf = (word: CellWord): LayoutGroup[] => layoutWord(word).groups;

export function occurrencesOn(column: CellColumn): CellId[] {
  return column.rule_occurrence_ids;
}
