import type { CellGroup } from './types';

/** Stable native group identity, in the producer's ordered column sequence. */
export const groupKey = (group: Pick<CellGroup, 'column_ids'>): string =>
  group.column_ids.map(String).join(':');
