import type { CellColumn, CellGroup, CellId, CellSound } from './types';

export type GroupKind = 'base' | 'vowel';

export interface TrackSpan {
  at: number;
  span: number;
}

export interface GroupColumn extends TrackSpan {
  slot: string;
  column: CellColumn;
  size: 'full' | 'small';
  pin: 'top' | 'bottom' | null;
  seamCapacity: number;
}

export interface PhonemeBox {
  sound: CellSound;
}

export interface PhonemeSpan extends TrackSpan {
  boxes: PhonemeBox[];
}

export interface WordPhonemeSpan extends PhonemeSpan {
  owner: CellId;
  inlineEndGap: number;
  inlineEndRunGap: number;
}

export interface LayoutGroup extends TrackSpan {
  key: CellId;
  raw: CellGroup;
  kind: GroupKind;
  cols: GroupColumn[];
  spans: PhonemeSpan[];
  gapAfter: number;
  runGapAfter: number;
}

export interface GlyphSizer {
  at: number;
  column: CellColumn;
  seamCapacity: number;
}

export interface SoundSizer extends TrackSpan {
  sounds: CellSound[];
  seamCapacity: number;
}

export interface WordLayout {
  trackCount: number;
  template: string;
  groups: LayoutGroup[];
  spans: WordPhonemeSpan[];
  glyphs: GlyphSizer[];
  sounds: SoundSizer[];
  seams: Array<{ id: string; active: boolean; absorber: string | null }>;
  descriptor: string;
}
