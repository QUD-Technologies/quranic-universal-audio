/**
 * Per-glyph calibration for a bare combining mark drawn on its own.
 *
 * A lone haraka is a zero-width combining glyph whose ink sits at a different
 * size and offset in the em for every mark, so one scale and one nudge cannot
 * serve them all. These numbers were tuned against the DigitalKhatt face in the
 * QUA Inspector and are copied from it; they belong to that face, not to a
 * reading, so they live in the renderer.
 */

export interface MarkRender {
  /** Glyph size as a multiple of the letter font. */
  scale: number;
  /** Horizontal nudge to centre the ink, in em. Negative moves left. */
  shiftEm: number;
  /** Vertical nudge, in em. Negative moves up. */
  raiseEm: number;
}

const DEFAULT: MarkRender = { scale: 1.4, shiftEm: 0, raiseEm: 0 };

const BY_CODEPOINT: Record<string, MarkRender> = {
  '64e': { scale: 1.01, shiftEm: -0.11, raiseEm: -0.335 }, // fatha
  '64f': { scale: 0.9, shiftEm: -0.11, raiseEm: -0.215 }, // damma
  '650': { scale: 0.99, shiftEm: -0.125, raiseEm: -0.24 }, // kasra
  '64b': { scale: 0.62, shiftEm: -0.115, raiseEm: -0.23 }, // fathatan
  '64c': { scale: 0.9, shiftEm: -0.13, raiseEm: -0.17 }, // dammatan
  '64d': { scale: 1.09, shiftEm: -0.125, raiseEm: -0.23 }, // kasratan
  '8f0': { scale: 1.15, shiftEm: -0.145, raiseEm: -0.345 }, // fathatan, open
  '8f1': { scale: 0.79, shiftEm: -0.205, raiseEm: -0.24 }, // dammatan, open
  '8f2': { scale: 1.13, shiftEm: -0.11, raiseEm: -0.355 }, // kasratan, open
  '6e2': { scale: 0.8, shiftEm: -0.035, raiseEm: -0.275 }, // mini meem, above
  '6ed': { scale: 0.81, shiftEm: -0.09, raiseEm: -0.212 }, // mini meem, below
  '6dc': { scale: 0.86, shiftEm: -0.23, raiseEm: -0.215 }, // mini seen, above
  '6e3': { scale: 0.86, shiftEm: -0.23, raiseEm: -0.215 }, // mini seen, below
};

export function markRenderFor(glyph: string): MarkRender {
  const codepoint = glyph.codePointAt(0)?.toString(16);
  return (codepoint && BY_CODEPOINT[codepoint]) || DEFAULT;
}

/** The Inspector uses the cleaner isolated low-meem ink in either pin slot. */
export const markGlyphFor = (source: string): string => source === 'ۢ' ? 'ۭ' : source;

/** The `--haraka-*` custom properties `.haraka-cell .g` reads. */
export function markRenderStyle(glyph: string): string {
  const r = markRenderFor(glyph);
  return `--haraka-scale:${r.scale};--haraka-shift:${r.shiftEm}em;--haraka-raise:${r.raiseEm}em`;
}
