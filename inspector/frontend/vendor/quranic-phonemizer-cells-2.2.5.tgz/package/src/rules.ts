/**
 * Rule badges: which underlines a cell draws, and what they are called.
 *
 * The renderer holds no rule inventory. It never tests a rule id. The host
 * passes a registry keyed by rule id, and the colour of a rule is whatever CSS
 * custom property that registry names, so adding a rule is a registry change
 * and nothing else.
 *
 * Bars stack bottom upward in a fixed order, so a cross-word merger riding on a
 * ghunnah always sits above it and weight always sits on top. Without that the
 * same pair of rules would swap places between two cells.
 */
import type { CellContext, CellId, RuleDefinition, RuleVisual } from './types';

const BAR_PX = 2;
const BORDER_PX = 2;

const DEPTH: Record<RuleDefinition['stack'], number> = { base: 0, merge: 1, top: 2 };

export interface Badge {
  rule: RuleDefinition;
}

/** The badges a cell draws, innermost bar first. */
export function badgesFor(occurrenceIds: CellId[], context: CellContext): Badge[] {
  const seen = new Set<string>();
  const badges: Badge[] = [];
  for (const id of occurrenceIds) {
    const occurrence = context.occurrences[id];
    if (!occurrence) continue;
    const rule = context.rules[occurrence.rule_id];
    if (!rule) continue;
    /* A silence has no legend row and no toggle, so it is keyed by its own id
       and is always named. */
    const key = rule.legend_key || rule.id;
    if (seen.has(key)) continue;
    if (rule.legend_key && context.disabled?.has(rule.legend_key)) continue;
    seen.add(key);
    badges.push({ rule });
  }
  return badges.sort((a, b) => DEPTH[a.rule.stack] - DEPTH[b.rule.stack]);
}

/**
 * How many bars a cell draws. A cell reserves this much space below its glyph,
 * so an underline never lands on the ink it belongs to.
 */
export const barCountOf = (badges: Badge[]): number =>
  badges.filter(
    (badge) => badge.rule.color_var !== null && (badge.rule.visual ?? 'underline') !== 'border',
  ).length;

const visualOf = (badge: Badge): RuleVisual => badge.rule.visual ?? 'underline';

/** The colour for a rule whose underline wraps up the cell edges. */
export function wrapColorFor(badges: Badge[]): string {
  const badge = badges.find((candidate) => visualOf(candidate) === 'wrap');
  return badge?.rule.color_var ? `var(${badge.rule.color_var})` : '';
}

/** The stacked underline, as one box-shadow. */
export function barsFor(badges: Badge[]): string {
  let offset = 0;
  return badges
    .filter((badge) => badge.rule.color_var !== null)
    .map((badge) => {
      if (visualOf(badge) === 'border') {
        return `inset 0 0 0 ${BORDER_PX}px var(${badge.rule.color_var})`;
      }
      offset += BAR_PX;
      return `inset 0 -${offset}px 0 var(${badge.rule.color_var})`;
    })
    .join(', ');
}

/** Rule names for the hover tip, one per line. Names only, never prose. */
export function namesFor(badges: Badge[], silence: string | null, context: CellContext): string {
  const names = badges.map((badge) => badge.rule.label);
  if (silence) {
    const rule = context.rules[silence];
    if (rule && !names.includes(rule.label)) names.push(rule.label);
  }
  return names.join('\n');
}
