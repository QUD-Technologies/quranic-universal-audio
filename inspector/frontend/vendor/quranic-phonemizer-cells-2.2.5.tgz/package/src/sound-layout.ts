import type { CellId, CellSound, CellWord } from './types';
import { LayoutInvariantError, type StableWordVariant } from './union';
import type {
  LayoutGroup,
  PhonemeSpan,
  TrackSpan,
  WordPhonemeSpan,
} from './layout-types';

function envelopeOf(values: number[], where: string): TrackSpan {
  const sorted = [...new Set(values)].sort((a, b) => a - b);
  if (sorted.length === 0) throw new LayoutInvariantError(`${where}: empty track range`);
  return { at: sorted[0]!, span: sorted.at(-1)! - sorted[0]! + 1 };
}

function soundingColumnIds(word: CellWord, sound: CellSound): CellId[] {
  const columns = new Map(word.columns.map((column) => [column.id, column]));
  return sound.column_ids.filter((id) => columns.get(id)?.silence === null);
}

function addCrossGroupSpan(
  ids: CellId[], sound: CellSound, host: CellId | undefined,
  groupAt: Map<CellId, number>, ranges: Map<CellId, TrackSpan>,
  buckets: Map<string, WordPhonemeSpan>, where: string, required = false,
): void {
  const touched = new Set(ids.map((id) => groupAt.get(id)));
  touched.delete(undefined);
  if (touched.size < 2) {
    if (required) throw new LayoutInvariantError(`${where} does not cross groups`);
    return;
  }
  const tracks = ids.flatMap((id) => {
    const range = ranges.get(id);
    return range
      ? Array.from({ length: range.span }, (_, at) => range.at + at)
      : [];
  });
  const range = envelopeOf(tracks, where);
  if (host === undefined) throw new LayoutInvariantError(`${where} has no host group`);
  const key = `${String(host)}:${range.at}:${range.span}`;
  const bucket = buckets.get(key);
  if (bucket) bucket.boxes.push({ sound });
  else buckets.set(key, {
    owner: host,
    ...range,
    boxes: [{ sound }],
    inlineEndGap: 0,
    inlineEndRunGap: 0,
  });
}

function withEndpointGap(
  span: WordPhonemeSpan, groups: LayoutGroup[],
): WordPhonemeSpan {
  const end = span.at + span.span;
  const endpoint = groups.find((group) => group.at < end && end <= group.at + group.span);
  const reachesGroupEnd = endpoint !== undefined && end === endpoint.at + endpoint.span;
  return {
    ...span,
    inlineEndGap: reachesGroupEnd ? endpoint.gapAfter : 0,
    inlineEndRunGap: reachesGroupEnd ? endpoint.runGapAfter : 0,
  };
}

export function localSoundSpans(
  word: CellWord,
  raw: CellWord['groups'][number],
  variant: StableWordVariant,
  cellRanges: Map<string, TrackSpan>,
  groupStart: number,
): PhonemeSpan[] {
  const buckets = new Map<string, PhonemeSpan>();
  const members = new Set(raw.column_ids);
  const groupOf = new Map(word.groups.flatMap((group) =>
    group.column_ids.map((id) => [id, group.key] as const)
  ));
  for (const soundId of raw.sound_ids) {
    const sound = word.sounds.find((candidate) => candidate.sound_id === soundId);
    if (!sound) throw new LayoutInvariantError(
      `${word.location} ${variant.state}: group sound ${String(soundId)} is missing`,
    );
    const soundingIds = soundingColumnIds(word, sound);
    if (soundingIds.some((id) =>
      groupOf.has(id) && groupOf.get(id) !== raw.key
    )) continue;
    const slots = soundingIds.filter((id) => members.has(id))
      .map((id) => variant.keyById.get(id))
      .filter((slot): slot is string => slot !== undefined);
    const tracks = slots.flatMap((slot) => {
      const range = cellRanges.get(slot);
      return range ? Array.from({ length: range.span }, (_, at) => range.at + at) : [];
    });
    const range = envelopeOf(tracks, `${word.location} ${variant.state} sound ${String(soundId)}`);
    const key = `${range.at}:${range.span}`;
    const bucket = buckets.get(key);
    if (bucket) bucket.boxes.push({ sound });
    else buckets.set(key, { at: range.at - groupStart, span: range.span, boxes: [{ sound }] });
  }
  return [...buckets.values()];
}

export function crossGroupSpans(
  word: CellWord, groups: LayoutGroup[],
): WordPhonemeSpan[] {
  const groupAt = new Map<CellId, number>();
  const ranges = new Map<CellId, TrackSpan>();
  groups.forEach((group, index) => group.cols.forEach((col) => {
    groupAt.set(col.column.id, index);
    ranges.set(col.column.id, { at: group.at + col.at, span: col.span });
  }));
  const owner = new Map(word.groups.flatMap((group) =>
    group.sound_ids.map((sound) => [sound, group.key] as const)
  ));
  const buckets = new Map<string, WordPhonemeSpan>();
  for (const sound of word.sounds) {
    addCrossGroupSpan(
      soundingColumnIds(word, sound), sound, owner.get(sound.sound_id),
      groupAt, ranges, buckets,
      `${word.location} sound ${String(sound.sound_id)}`,
    );
  }
  for (const bridge of word.bridges) {
    const ids = [...bridge.before_column_ids, ...bridge.after_column_ids];
    const host = word.groups.find((group) =>
      group.column_ids.some((id) => bridge.after_column_ids.includes(id))
    )?.key;
    addCrossGroupSpan(
      ids, bridge.sound, host,
      groupAt, ranges, buckets,
      `${word.location} bridge ${String(bridge.merger_id)}`, true,
    );
  }
  return [...buckets.values()].map((span) => withEndpointGap(span, groups));
}
