/**
 * The cell view as the phonemizer publishes it.
 *
 * This mirrors the CellView contract in the phonemizer's
 * `docs/design/consumer-analysis-projection.md` section 9.1. Nothing here is
 * inferred by the renderer: every field is something the producer decided.
 */

export type ColumnRole =
  | 'letter'
  | 'haraka'
  | 'sukun'
  | 'tanween'
  | 'madd'
  | 'stop_sign'
  | 'gap';

export type Tier = 'main' | 'above' | 'below';

export type Status = 'present' | 'inserted' | 'replaced' | 'dropped' | 'gap';

export type Side = 'before' | 'after';

/** A junction between two words, as the resolved reading left it. */
export type BoundaryState = 'start' | 'join' | 'sakt' | 'stop';

export type CellId = string | number;
export type CrossWordMergerMode = 'compact' | 'extend';
export type VerseFlow = 'break' | 'inline';

/** Theme/timing hosts may decorate native entities without changing them. */
export type HostClass<T> = (item: T, index?: number) => string | null | undefined;

export interface CellColumn {
  id: CellId;
  role: ColumnRole;
  /** Exactly what to draw. Composed marks (shadda, maddah, silence) are in here. */
  text: string;
  source_character_ids: CellId[];
  source_unit_ids: CellId[];
  /** Canonical slots this projected column spells or presents. */
  slot_ids: CellId[];
  tier: Tier;
  /** Which main column this rides. Stated by the producer, never guessed. */
  attached_to_column_id: CellId | null;
  status: Status;
  variant_id: string | null;
  variant_choice: string | null;
  anchor_unit_id: CellId | null;
  side: Side | null;
  owned_sound_ids: CellId[];
  presented_sound_ids: CellId[];
  rule_occurrence_ids: CellId[];
  /** Why this column makes no sound, or null when it does. */
  silence: string | null;
}

export interface CellSound {
  sound_id: CellId;
  /** The phoneme token. */
  text: string;
  column_ids: CellId[];
  rule_occurrence_ids: CellId[];
}

export interface CellBridge {
  merger_id: CellId;
  before_column_ids: CellId[];
  after_column_ids: CellId[];
  sound: CellSound;
}

export interface CellRun {
  id: CellId;
  /** The compact source letter this named-letter run expands. */
  source_unit_id: CellId;
  column_ids: CellId[];
}

export interface CellGroup {
  key: CellId;
  kind: 'base' | 'vowel';
  column_ids: CellId[];
  sound_ids: CellId[];
}

export interface CellWord {
  word_id: CellId;
  /** Reference of the form `surah:ayah:word`. */
  location: string;
  /** The word as connected script, for the line above the grid. */
  display_text: string;
  columns: CellColumn[];
  sounds: CellSound[];
  groups: CellGroup[];
  /** Flat named-letter spans; empty for an ordinary word. */
  runs: CellRun[];
  /** Producer-declared mergers whose two endpoints are inside this word. */
  bridges: CellBridge[];
}

export interface CellBoundary {
  boundary_id: CellId;
  state: BoundaryState;
  columns: CellColumn[];
  sounds: CellSound[];
  bridges: CellBridge[];
  /** The verse this junction closes, when it closes one: the number as the
   *  mushaf prints it, to be drawn inside the end-of-ayah mark. Null mid-verse. */
  verse_end?: string | null;
  /** Junctions of which at most one may be taken, the muanaqah pair being the
   *  only one the mushaf marks. Boundaries sharing a key exclude each other. */
  exclusive_group?: string | null;
}

export interface CellView {
  words: CellWord[];
  /** In reading order: boundaries[i] follows words[i]. The last one closes the
   *  reading, so there can be one per word. */
  boundaries: CellBoundary[];
}

/** Which underline a rule occupies when bars stack, innermost first. */
export type StackLayer = 'base' | 'merge' | 'top';

/** How a rule marks the cell beyond the default bottom underline. */
export type RuleVisual = 'underline' | 'border' | 'wrap';

/** One tajweed rule, as the host's registry defines it. */
export interface RuleDefinition {
  id: string;
  /** Shown in the hover tip and the legend. A name, never a sentence. */
  label: string;
  /** Rules sharing a key share one colour, one legend row and one toggle.
   *  Empty for a rule that has no legend row. */
  legend_key: string;
  /** The custom property holding this rule's colour, or null for a rule that
   *  is named on hover but draws no bar (the silences). */
  color_var: string | null;
  stack: StackLayer;
  /** Optional cell treatment; omitted rules use the normal underline. */
  visual?: RuleVisual;
}

/** Optional host-owned classes for visible native entities. */
export interface HostClasses {
  word?: HostClass<CellWord>;
  group?: HostClass<CellGroup>;
  column?: HostClass<CellColumn>;
  sound?: HostClass<CellSound>;
  boundary?: HostClass<CellBoundary>;
  bridge?: HostClass<CellBridge>;
}

export interface RuleOccurrence {
  id: CellId;
  rule_id: string;
}

/** Everything the renderer needs that is not the view itself. */
export interface CellContext {
  occurrences: Record<string, RuleOccurrence>;
  rules: Record<string, RuleDefinition>;
  /** Legend keys the viewer has switched off. */
  disabled?: Set<string>;
}
