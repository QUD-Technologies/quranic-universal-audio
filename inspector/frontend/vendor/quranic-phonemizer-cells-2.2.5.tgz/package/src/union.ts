import type {
  BoundaryState,
  CellBoundary,
  CellColumn,
  CellId,
  CellSound,
  CellView,
  CellWord,
} from './types';

export class LayoutInvariantError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'LayoutInvariantError';
  }
}

export interface StableGroupVariant {
  host: string;
  kind: 'base' | 'vowel';
  slots: string[];
  soundIds: CellId[];
}

export interface StableWordVariant {
  state: string;
  word: CellWord;
  keys: string[];
  keyById: Map<CellId, string>;
  groups: StableGroupVariant[];
}

export interface StableSeam {
  id: string;
  left: string;
  right: string;
  after: number;
  activeStates: Set<string>;
}

export interface GlyphConstraint {
  slot: string;
  column: CellColumn;
}

export interface SoundConstraint {
  slots: string[];
  sounds: CellSound[];
}

export interface StableWordLayout {
  location: string;
  slots: string[];
  seams: StableSeam[];
  variants: Map<string, StableWordVariant>;
  glyphs: GlyphConstraint[];
  sounds: SoundConstraint[];
}

export interface StableBoundaryLayout {
  variants: CellBoundary[];
  potentialBridge: boolean;
}

export interface StableLayout {
  words: Map<string, StableWordLayout>;
  boundaries: Map<string, StableBoundaryLayout>;
}

export function groupSoundConstraints(
  variant: StableWordVariant,
): SoundConstraint[] {
  const byId = new Map(variant.word.sounds.map((sound) => [sound.sound_id, sound]));
  const buckets = new Map<string, SoundConstraint>();
  for (const group of variant.groups) {
    const members = new Set(group.slots);
    for (const soundId of group.soundIds) {
      const sound = byId.get(soundId);
      if (!sound) throw new LayoutInvariantError(
        `${variant.word.location} ${variant.state}: group sound ${String(soundId)} is missing`,
      );
      const slots = sound.column_ids.map((id) => variant.keyById.get(id))
        .filter((slot): slot is string => slot !== undefined && members.has(slot));
      if (slots.length === 0) throw new LayoutInvariantError(
        `${variant.word.location} ${variant.state}: sound ${String(soundId)} has no group span`,
      );
      const key = `${group.host}|${slots.join('|')}`;
      const bucket = buckets.get(key) ?? { slots, sounds: [] };
      bucket.sounds.push(sound);
      buckets.set(key, bucket);
    }
  }
  return [...buckets.values()];
}

export const canonicalStopSets = (locations: string[]): string[][] => [
  [],
  [...locations],
  locations.filter((_, index) => index % 2 === 0),
  locations.filter((_, index) => index % 2 === 1),
];

const freshBefore = (state: BoundaryState | undefined) =>
  state === undefined || state === 'start' || state === 'stop';

export function wordState(view: CellView, index: number): string {
  const before = view.boundaries[index - 1]?.state;
  const after = view.boundaries[index]?.state ?? 'stop';
  return `${freshBefore(before) ? 'fresh' : 'joined'}/${after}`;
}

function stemOf(column: CellColumn, gap: number): string {
  if (column.slot_ids.length > 0) {
    const tier = column.tier === 'main' ? 'main' : 'mark';
    return `c${column.slot_ids.map(String).join('+')}:${tier}`;
  }
  if (column.source_unit_ids.length > 0) {
    const tier = column.tier === 'main' ? 'main' : 'mark';
    return `${String(column.source_unit_ids[0])}:${tier}`;
  }
  if (column.role === 'gap') return `g:${gap}`;
  return `a${String(column.anchor_unit_id)}:${String(column.side)}`;
}

export function slotKeys(word: CellWord): string[] {
  const seen = new Map<string, number>();
  let gap = 0;
  return word.columns.map((column) => {
    if (column.role === 'gap') gap += 1;
    const stem = stemOf(column, gap);
    const occurrence = (seen.get(stem) ?? 0) + 1;
    seen.set(stem, occurrence);
    return `${stem}:${occurrence}`;
  });
}

function renderOrder(word: CellWord, keyById: Map<CellId, string>): string[] {
  const grouped = word.groups.flatMap((group) =>
    group.column_ids.map((id) => keyById.get(id)).filter((key): key is string => key !== undefined)
  );
  const claimed = new Set(grouped);
  return [...grouped, ...word.columns.map((column) => keyById.get(column.id)!)
    .filter((key) => !claimed.has(key))];
}

function merge(left: string[], right: string[]): string[] {
  const common = Array.from({ length: left.length + 1 }, () =>
    new Array<number>(right.length + 1).fill(0),
  );
  for (let i = left.length - 1; i >= 0; i--) {
    for (let j = right.length - 1; j >= 0; j--) {
      common[i]![j] = left[i] === right[j]
        ? common[i + 1]![j + 1]! + 1
        : Math.max(common[i + 1]![j]!, common[i]![j + 1]!);
    }
  }
  const out: string[] = [];
  let i = 0;
  let j = 0;
  while (i < left.length && j < right.length) {
    if (left[i] === right[j]) {
      out.push(left[i++]!);
      j += 1;
    } else if (common[i + 1]![j]! >= common[i]![j + 1]!) out.push(left[i++]!);
    else out.push(right[j++]!);
  }
  return [...out, ...left.slice(i), ...right.slice(j)];
}

function variantOf(word: CellWord, state: string): StableWordVariant {
  const rawKeys = slotKeys(word);
  const keyById = new Map(word.columns.map((column, at) => [column.id, rawKeys[at]!]));
  const keys = renderOrder(word, keyById);
  const groups = word.groups.map((group) => {
    const host = keyById.get(group.key);
    if (!host) throw new LayoutInvariantError(
      `${word.location} ${state}: group ${String(group.key)} has no stable host`,
    );
    return {
      host,
      kind: group.kind,
      slots: group.column_ids.map((id) => {
        const key = keyById.get(id);
        if (!key) throw new LayoutInvariantError(
          `${word.location} ${state}: group ${String(group.key)} names ${String(id)}`,
        );
        return key;
      }),
      soundIds: [...group.sound_ids],
    };
  });
  return { state, word, keys, keyById, groups };
}

function sameVariant(left: StableWordVariant, right: StableWordVariant): boolean {
  const shape = (one: StableWordVariant) => JSON.stringify({
    keys: one.keys,
    groups: one.groups.map(({ host, kind, slots }) => ({ host, kind, slots })),
  });
  return shape(left) === shape(right);
}

export function collectSeams(
  slots: string[], variants: StableWordVariant[],
): StableSeam[] {
  const index = new Map(slots.map((slot, at) => [slot, at]));
  const seams = new Map<string, StableSeam>();
  for (const variant of variants) {
    const groupAt = new Map<string, number>();
    variant.groups.forEach((group, at) => group.slots.forEach((slot) => groupAt.set(slot, at)));
    for (let at = 0; at < variant.keys.length - 1; at++) {
      const left = variant.keys[at]!;
      const right = variant.keys[at + 1]!;
      if (groupAt.get(left) === groupAt.get(right)) continue;
      const rightAt = index.get(right);
      const cut = rightAt === undefined ? undefined : rightAt - 1;
      if (cut === undefined || index.get(left) === undefined) continue;
      const id = `${left}|${right}`;
      const seam = seams.get(id) ?? {
        id, left, right, after: cut, activeStates: new Set<string>(),
      };
      seam.activeStates.add(variant.state);
      seams.set(id, seam);
    }
  }
  return [...seams.values()].sort((a, b) => a.after - b.after || a.id.localeCompare(b.id));
}

function collectConstraints(variants: StableWordVariant[]) {
  const glyphs: GlyphConstraint[] = [];
  const sounds: SoundConstraint[] = [];
  const seenGlyph = new Set<string>();
  const seenSound = new Set<string>();
  for (const variant of variants) {
    variant.word.columns.forEach((column) => {
      const slot = variant.keyById.get(column.id)!;
      const signature = `${slot}|${column.tier}|${column.text}`;
      if (!seenGlyph.has(signature)) glyphs.push({ slot, column });
      seenGlyph.add(signature);
    });
    for (const bucket of groupSoundConstraints(variant)) {
      const signature = `${bucket.slots.join('|')}|${bucket.sounds.map((sound) => sound.text).join('|')}`;
      if (!seenSound.has(signature)) sounds.push(bucket);
      seenSound.add(signature);
    }
  }
  return { glyphs, sounds };
}

function buildWord(location: string, entries: Array<{ state: string; word: CellWord }>) {
  const byState = new Map<string, StableWordVariant>();
  let slots: string[] = [];
  for (const { state, word } of entries) {
    const variant = variantOf(word, state);
    slots = slots.length === 0 ? variant.keys : merge(slots, variant.keys);
    const prior = byState.get(state);
    if (prior && !sameVariant(prior, variant)) throw new LayoutInvariantError(
      `${location} ${state}: canonical views disagree for the same local state`,
    );
    byState.set(state, variant);
  }
  const variants = [...byState.values()];
  const constraints = collectConstraints(variants);
  return {
    location,
    slots,
    seams: collectSeams(slots, variants),
    variants: byState,
    ...constraints,
  } satisfies StableWordLayout;
}

export function buildStableLayout(canonical: CellView[]): StableLayout {
  if (canonical.length === 0) throw new LayoutInvariantError('Stable layout needs a view');
  const entries = new Map<string, Array<{ state: string; word: CellWord }>>();
  const boundaryEntries = new Map<string, CellBoundary[]>();
  for (const view of canonical) {
    view.words.forEach((word, index) => {
      entries.set(word.location, [
        ...(entries.get(word.location) ?? []),
        { state: wordState(view, index), word },
      ]);
      const boundary = view.boundaries[index];
      if (boundary) boundaryEntries.set(
        word.location,
        [...(boundaryEntries.get(word.location) ?? []), boundary],
      );
    });
  }
  const words = new Map<string, StableWordLayout>();
  entries.forEach((variants, location) => words.set(location, buildWord(location, variants)));
  const boundaries = new Map<string, StableBoundaryLayout>();
  boundaryEntries.forEach((variants, location) => boundaries.set(location, {
    variants,
    potentialBridge: variants.some((boundary) => boundary.bridges.length > 0),
  }));
  return { words, boundaries };
}
