/** The two script conveniences the renderer owns: iqlab and tanween form. */
import type {
  CellColumn,
  CellContext,
  CellId,
  CellSound,
  CellView,
  CellWord,
} from './types';
import {
  LayoutInvariantError,
  slotKeys,
  type StableWordLayout,
} from './union';

type VisualColumn = CellColumn & {
  visual_kind?: 'iqlab_meem';
  visual_vowel?: string;
};

const FATHA = 'َ';
const DAMMA = 'ُ';
const KASRA = 'ِ';
const MEEM_ABOVE = 'ۢ';
const MEEM_BELOW = 'ۭ';

const TANWEEN = new Map([
  ['ً', { vowel: FATHA, open: 'ࣰ', meem: MEEM_ABOVE }],
  ['ٌ', { vowel: DAMMA, open: 'ࣱ', meem: MEEM_ABOVE }],
  ['ٍ', { vowel: KASRA, open: 'ࣲ', meem: MEEM_BELOW }],
]);

const OPEN_RULES = new Set([
  'idgham_bi_ghunnah',
  'idgham_bila_ghunnah',
  'ikhfaa',
]);

export interface RendererOptions {
  /** How an iqlab tanween is drawn. */
  iqlabTanween?: 'mini-meem' | 'tanween';
  /** How a written noon under iqlab is drawn. */
  iqlabNoon?: 'mini-meem' | 'noon';
  /** Open assimilated tanween; false keeps every tanween closed/stacked. */
  openTanween?: boolean;
}

export const DEFAULT_RENDERER_OPTIONS: Required<RendererOptions> = {
  iqlabTanween: 'mini-meem',
  iqlabNoon: 'mini-meem',
  openTanween: true,
};

const resolved = (options: RendererOptions): Required<RendererOptions> => ({
  ...DEFAULT_RENDERER_OPTIONS,
  ...options,
});

const ruleOf = (id: CellId, context: CellContext) => context.occurrences[id]?.rule_id;

function iqlabIds(column: CellColumn, context: CellContext): CellId[] {
  return column.rule_occurrence_ids.filter((id) => ruleOf(id, context) === 'iqlab');
}

function iqlabSounds(column: CellColumn, sounds: CellSound[], ids: CellId[]): Set<CellId> {
  return new Set(
    sounds.filter((sound) =>
      column.owned_sound_ids.includes(sound.sound_id)
      && sound.rule_occurrence_ids.some((id) => ids.includes(id)),
    ).map((sound) => sound.sound_id),
  );
}

function meemColumn(
  word: CellWord, column: CellColumn, ids: CellId[], sounds: Set<CellId>,
): VisualColumn {
  const tanween = TANWEEN.get(column.text);
  return {
    ...column,
    id: `visual:iqlab:${word.location}:${String(column.id)}`,
    role: 'tanween' as const,
    text: tanween?.meem ?? MEEM_ABOVE,
    source_character_ids: [],
    source_unit_ids: [],
    tier: tanween?.meem === MEEM_BELOW ? ('below' as const) : ('above' as const),
    attached_to_column_id: column.id,
    status: 'present' as const,
    rule_occurrence_ids: ids,
    silence: null,
    owned_sound_ids: [...sounds],
    presented_sound_ids: [],
    anchor_unit_id: column.source_unit_ids[0] ?? column.anchor_unit_id,
    side: 'after' as const,
    visual_kind: 'iqlab_meem' as const,
    visual_vowel: tanween?.vowel,
  };
}

const isIqlabMeem = (column: CellColumn): column is VisualColumn =>
  (column as VisualColumn).visual_kind === 'iqlab_meem';

function keyMap(word: CellWord): Map<CellId, string> {
  const keys = slotKeys(word);
  return new Map(word.columns.map((column, at) => [column.id, keys[at]!]));
}

function dormantSource(
  word: CellWord, plan: StableWordLayout, slot: string, donor: VisualColumn,
) {
  const donorVariant = [...plan.variants.values()].find(
    (variant) => variant.keyById.get(donor.id) === slot,
  );
  const sourceSlot = donorVariant && donor.attached_to_column_id !== null
    ? donorVariant.keyById.get(donor.attached_to_column_id)
    : undefined;
  const now = keyMap(word);
  const sourceId = sourceSlot
    ? [...now].find(([, key]) => key === sourceSlot)?.[0]
    : undefined;
  return sourceId === undefined
    ? word.columns.find((column) => donor.anchor_unit_id !== null
      && column.source_unit_ids.includes(donor.anchor_unit_id))
    : word.columns.find((column) => column.id === sourceId);
}

function addDormantIqlab(
  word: CellWord, plan: StableWordLayout, slot: string, donor: VisualColumn,
): CellWord {
  const now = keyMap(word);
  if ([...now.values()].includes(slot)) return word;
  const source = dormantSource(word, plan, slot, donor);
  const group = source && word.groups.find((candidate) =>
    candidate.column_ids.includes(source.id)
  );
  if (!source || !group) throw new LayoutInvariantError(
    `${word.location}: dormant iqlab ${slot} has no current source group`,
  );
  const meem: VisualColumn = {
    ...donor,
    id: `visual:dormant:${word.location}:${slot}`,
    attached_to_column_id: source.id,
    owned_sound_ids: [],
    presented_sound_ids: [],
    rule_occurrence_ids: [],
    status: 'dropped',
    silence: 'iqlab',
  };
  const order = new Map(plan.slots.map((key, at) => [key, at]));
  const ids = [...group.column_ids, meem.id].sort((left, right) =>
    order.get(left === meem.id ? slot : now.get(left)!)!
      - order.get(right === meem.id ? slot : now.get(right)!)!
  );
  return {
    ...word,
    columns: [...word.columns, meem],
    groups: word.groups.map((candidate) =>
      candidate === group ? { ...candidate, column_ids: ids } : candidate
    ),
  };
}

export function materializeDormantIqlab(word: CellWord, plan: StableWordLayout): CellWord {
  return plan.glyphs.reduce((rendered, { slot, column }) =>
    isIqlabMeem(column) ? addDormantIqlab(rendered, plan, slot, column) : rendered,
  word);
}

function sourceHalf(column: CellColumn, ids: CellId[], sounds: Set<CellId>) {
  const tanween = TANWEEN.get(column.text);
  const keptRules = column.rule_occurrence_ids.filter((id) => !ids.includes(id));
  const keptSounds = column.owned_sound_ids.filter((id) => !sounds.has(id));
  if (tanween) {
    return {
      ...column, role: 'haraka' as const, text: tanween.vowel,
      status: 'present' as const, rule_occurrence_ids: keptRules,
      owned_sound_ids: keptSounds, silence: null,
    };
  }
  return {
    ...column, status: 'dropped' as const, rule_occurrence_ids: keptRules,
    owned_sound_ids: keptSounds, silence: 'iqlab',
  };
}

function splitIqlab(
  word: CellWord, context: CellContext, options: Required<RendererOptions>,
): CellWord {
  let columns = [...word.columns];
  let sounds = [...word.sounds];
  let groups = word.groups.map((group) => ({ ...group, column_ids: [...group.column_ids] }));
  for (const column of word.columns) {
    if (String(column.id).startsWith('visual:iqlab:')) continue;
    const ids = iqlabIds(column, context);
    if (ids.length === 0 || (column.role !== 'letter' && column.role !== 'tanween')) continue;
    if (column.role === 'tanween' && options.iqlabTanween === 'tanween') continue;
    if (column.role === 'letter' && options.iqlabNoon === 'noon') continue;
    const moved = iqlabSounds(column, sounds, ids);
    if (moved.size === 0) continue;
    const meem = meemColumn(word, column, ids, moved);
    columns = columns.flatMap((one) => one.id === column.id ? [sourceHalf(one, ids, moved), meem] : [one]);
    sounds = sounds.map((sound) => moved.has(sound.sound_id)
      ? { ...sound, column_ids: sound.column_ids.map((id) => id === column.id ? meem.id : id) }
      : sound);
    groups = groups.map((group) => group.column_ids.includes(column.id)
      ? { ...group, column_ids: group.column_ids.flatMap((id) => id === column.id ? [id, meem.id] : [id]) }
      : group);
  }
  return { ...word, columns, sounds, groups };
}

function openTanween(
  word: CellWord, context: CellContext, options: Required<RendererOptions>,
): CellWord {
  if (!options.openTanween) return word;
  const openRules = options.iqlabTanween === 'tanween'
    ? new Set([...OPEN_RULES, 'iqlab'])
    : OPEN_RULES;
  return {
    ...word,
    columns: word.columns.map((column) => {
      if (column.role !== 'tanween') return column;
      const form = TANWEEN.get(column.text);
      const open = column.rule_occurrence_ids.some(
        (id) => openRules.has(ruleOf(id, context) ?? ''),
      );
      return form && open ? { ...column, text: form.open } : column;
    }),
  };
}

export function applyVisualConventions(
  view: CellView, context: CellContext, options: RendererOptions = {},
): CellView {
  const chosen = resolved(options);
  return {
    ...view,
    words: view.words.map((word) =>
      openTanween(splitIqlab(word, context, chosen), context, chosen),
    ),
  };
}
