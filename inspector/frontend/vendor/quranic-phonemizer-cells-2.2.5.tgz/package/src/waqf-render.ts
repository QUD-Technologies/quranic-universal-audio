/**
 * Per-mark render calibration for a standalone waqf (stop) mark in a pause cell.
 *
 * Ported from the QUA Inspector. A lone waqf mark is a zero-width combining
 * glyph whose ink sits at a different size and offset in the em for every mark,
 * so one shared offset cannot centre them all. These values were tuned against
 * the DigitalKhatt face and are keyed by the mark's codepoint.
 */

export interface WaqfRender {
  /** Glyph font-size as a multiple of the word font. */
  scale: number;
  /** Horizontal nudge to centre the ink (em of the glyph; negative is left). */
  shiftEm: number;
  /** Vertical nudge to centre the ink (em of the glyph; negative is up). */
  raiseEm: number;
}

const DEFAULT_RENDER: WaqfRender = { scale: 1, shiftEm: -0.16, raiseEm: -0.22 };

const BY_CODEPOINT: Record<string, WaqfRender> = {
  '6d6': { scale: 1.02, shiftEm: -0.22, raiseEm: -0.24 }, // ۖ sala
  '6d7': { scale: 1.0, shiftEm: -0.16, raiseEm: -0.22 }, //  ۗ qila
  '6d8': { scale: 0.99, shiftEm: -0.24, raiseEm: -0.2 }, //  ۘ meem (lazim)
  '6da': { scale: 1.01, shiftEm: -0.12, raiseEm: -0.23 }, // ۚ jeem (jaiz)
  '6db': { scale: 1.19, shiftEm: -0.12, raiseEm: -0.3 }, //  ۛ muanaqah (three dots)
  '6dc': { scale: 1.0, shiftEm: -0.23, raiseEm: -0.22 }, // ۜ sakt
};

export function waqfRenderFor(mark: string): WaqfRender {
  const cp = mark.codePointAt(0)?.toString(16);
  return (cp && BY_CODEPOINT[cp]) || DEFAULT_RENDER;
}

/** The `--waqf-*` custom properties the `.pause-waqf` rule reads. */
export function waqfRenderStyle(mark: string): string {
  const r = waqfRenderFor(mark);
  return `--waqf-scale:${r.scale};--waqf-shift:${r.shiftEm}em;--waqf-raise:${r.raiseEm}em`;
}
