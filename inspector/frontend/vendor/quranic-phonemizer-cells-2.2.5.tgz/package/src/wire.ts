import type {
  CellBoundary,
  CellBridge,
  CellColumn,
  CellContext,
  CellGroup,
  CellRun,
  CellSound,
  CellView,
  CellWord,
  RuleDefinition,
  RuleOccurrence,
} from './types';
import { applyVisualConventions, type RendererOptions } from './visual';

export const SCHEMA_VERSION = 2;

export class SchemaMismatchError extends Error {
  constructor(document: string, received: unknown) {
    super(`${document} schema_version ${String(received)}, expected ${SCHEMA_VERSION}`);
    this.name = 'SchemaMismatchError';
  }
}

interface WireWord {
  id: number;
  ref: string;
  text: string;
  before_boundary_id: number;
  after_boundary_id: number;
  sound_ids: number[];
}

interface WireSound {
  id: number;
  order: number;
  token: string;
  word_id: number;
  rule_occurrence_ids: number[];
}

interface WireBoundary {
  id: number;
  before: number | null;
  after: number | null;
  state: CellBoundary['state'];
  stop_sign: string | null;
}

interface WireOccurrence {
  id: number;
  rule_id: string;
}

interface WireResult {
  words: WireWord[];
  boundaries: WireBoundary[];
  sounds: WireSound[];
  rule_occurrences: WireOccurrence[];
}

interface WireCellSound {
  sound_id: number;
  column_ids: number[];
  rule_occurrence_ids: number[];
}

interface WireColumn extends Omit<CellColumn, 'silence'> {
  silence: number | 'orthographic_silence' | 'variant_silence' | null;
}

interface WireCellWord {
  word_id: number;
  columns: WireColumn[];
  sounds: WireCellSound[];
  groups: CellGroup[];
  runs: CellRun[];
  bridges: WireBridge[];
}

interface WireBridge extends Omit<CellBridge, 'sound'> {
  sound: WireCellSound;
}

interface WireCellBoundary {
  boundary_id: number;
  columns: WireColumn[];
  sounds: WireCellSound[];
  bridges: WireBridge[];
  state: CellBoundary['state'];
  verse_end: number | null;
  exclusive_group: number | null;
}

export interface AnalysisDocument {
  schema_version: number;
  result: WireResult;
}

export interface CellDocument {
  schema_version: number;
  cell_view: {
    words: WireCellWord[];
    boundaries: WireCellBoundary[];
  };
}

export interface WirePayload {
  analysis: AnalysisDocument;
  cells: CellDocument;
}

export interface ParsedCells {
  view: CellView;
  context: CellContext;
}

export type DefineRule = (ruleId: string) => RuleDefinition;

const arabicNumber = (number: number) =>
  String(number).replace(/\d/g, (digit) => String.fromCharCode(0x0660 + Number(digit)));

const removeLast = (text: string, needle: string): string => {
  const at = text.lastIndexOf(needle);
  return at < 0 ? text : text.slice(0, at) + text.slice(at + needle.length);
};

/** Remove marks already represented by the following boundary tile. */
export function stripBoundaryMarks(text: string, boundary?: CellBoundary): string {
  const withoutOrnaments = text.replace(/\u06de/gu, '');
  const signs = boundary?.columns
    .filter((column) => column.role === 'stop_sign')
    .flatMap((column) => [...column.text]) ?? [];
  return signs.reduce((word, sign) => {
    const withoutCluster = removeLast(word, `\u034f${sign}`);
    return withoutCluster === word ? removeLast(word, sign) : withoutCluster;
  }, withoutOrnaments);
}

function assertVersions(payload: WirePayload): void {
  if (payload.analysis?.schema_version !== SCHEMA_VERSION) {
    throw new SchemaMismatchError('analysis', payload.analysis?.schema_version);
  }
  if (payload.cells?.schema_version !== SCHEMA_VERSION) {
    throw new SchemaMismatchError('cells', payload.cells?.schema_version);
  }
}

function soundOf(raw: WireCellSound, tokens: Map<number, string>): CellSound {
  const text = tokens.get(raw.sound_id);
  if (text === undefined) throw new Error(`Cell sound ${raw.sound_id} has no analysis token`);
  return { ...raw, text };
}

const bridgeOf = (raw: WireBridge, tokens: Map<number, string>): CellBridge => ({
  ...raw,
  sound: soundOf(raw.sound, tokens),
});

function silenceOf(
  raw: WireColumn['silence'],
  occurrences: Record<string, RuleOccurrence>,
): string | null {
  if (
    raw === null
    || raw === 'orthographic_silence'
    || raw === 'variant_silence'
  ) return raw;
  const occurrence = occurrences[raw];
  if (!occurrence) throw new Error(`Cell silence occurrence ${raw} does not exist`);
  return occurrence.rule_id;
}

function columnOf(
  raw: WireColumn,
  occurrences: Record<string, RuleOccurrence>,
): CellColumn {
  return { ...raw, silence: silenceOf(raw.silence, occurrences) };
}

function contextOf(result: WireResult, defineRule: DefineRule): CellContext {
  const occurrences: Record<string, RuleOccurrence> = {};
  const rules: Record<string, RuleDefinition> = {};
  for (const raw of result.rule_occurrences) {
    occurrences[raw.id] = { id: raw.id, rule_id: raw.rule_id };
    rules[raw.rule_id] ??= defineRule(raw.rule_id);
  }
  rules.orthographic_silence ??= defineRule('orthographic_silence');
  rules.variant_silence ??= defineRule('variant_silence');
  return { occurrences, rules };
}

function wordsOf(
  result: WireResult,
  cells: WireCellWord[],
  boundaries: WireCellBoundary[],
  context: CellContext,
): CellWord[] {
  const source = new Map(cells.map((word) => [word.word_id, word]));
  const boundary = new Map(boundaries.map((one) => [one.boundary_id, one]));
  const tokens = new Map(result.sounds.map((sound) => [sound.id, sound.token]));
  return result.words.map((word) => {
    const cell = source.get(word.id);
    if (!cell) throw new Error(`Analysis word ${word.id} has no cell word`);
    const after = boundary.get(word.after_boundary_id);
    return {
      word_id: word.id,
      location: word.ref,
      display_text: stripBoundaryMarks(
        word.text,
        after ? boundaryOf(after, tokens, context) : undefined,
      ),
      columns: cell.columns.map((column) => columnOf(column, context.occurrences)),
      sounds: cell.sounds.map((sound) => soundOf(sound, tokens)),
      groups: cell.groups,
      runs: cell.runs,
      bridges: cell.bridges.map((bridge) => bridgeOf(bridge, tokens)),
    };
  });
}

function boundaryOf(
  raw: WireCellBoundary,
  tokens: Map<number, string>,
  context: CellContext,
): CellBoundary {
  const columns = raw.columns.map((column) => columnOf(column, context.occurrences));
  const bridges = raw.bridges.map((bridge) => bridgeOf(bridge, tokens));
  return {
    boundary_id: raw.boundary_id,
    state: raw.state,
    columns,
    sounds: raw.sounds.map((sound) => soundOf(sound, tokens)),
    bridges,
    verse_end: raw.verse_end === null ? null : arabicNumber(raw.verse_end),
    exclusive_group:
      raw.exclusive_group === null ? null : `muanaqah-${raw.exclusive_group}`,
  };
}

function boundariesOf(
  result: WireResult,
  cells: WireCellBoundary[],
  context: CellContext,
): CellBoundary[] {
  const source = new Map(cells.map((boundary) => [boundary.boundary_id, boundary]));
  const tokens = new Map(result.sounds.map((sound) => [sound.id, sound.token]));
  return result.words.map((word) => {
    const raw = source.get(word.after_boundary_id);
    if (!raw) throw new Error(`Word ${word.id} has no cell boundary ${word.after_boundary_id}`);
    return boundaryOf(raw, tokens, context);
  });
}

export function parse(
  payload: WirePayload, defineRule: DefineRule, options: RendererOptions = {},
): ParsedCells {
  assertVersions(payload);
  const result = payload.analysis.result;
  const cells = payload.cells.cell_view;
  const context = contextOf(result, defineRule);
  const words = wordsOf(result, cells.words, cells.boundaries, context);
  const boundaries = boundariesOf(result, cells.boundaries, context);
  return {
    view: applyVisualConventions({ words, boundaries }, context, options),
    context,
  };
}
