<script lang="ts">
  import type { Snippet } from 'svelte';
  import type {
    CellBoundary,
    CellContext,
    CellView,
    CellWord,
    CrossWordMergerMode,
    HostClasses,
    VariantControlDefinition,
    VariantControlOccurrence,
    VariantControls,
    VerseFlow,
  } from './types';
  import { wordState, type StableLayout } from './union';
  import { stripBoundaryMarks } from './wire';
  import WordBlock from './WordBlock.svelte';
  import BoundaryTile from './BoundaryTile.svelte';
  import CrossWordBridge from './CrossWordBridge.svelte';
  import { isEmptySpot, spotOf, type VariantSpot } from './variant-spot';
  import { variantTip } from './variant-label';

  let {
    view,
    context,
    stableLayout,
    crossWordMergers = 'compact',
    verseFlow = 'break',
    showTooltips = true,
    hostClasses = {},
    keepBoundaryWithNext,
    wordAddon,
    ontoggleboundary,
    variantControls,
  }: {
    view: CellView;
    context: CellContext;
    stableLayout?: StableLayout;
    crossWordMergers?: CrossWordMergerMode;
    verseFlow?: VerseFlow;
    showTooltips?: boolean;
    hostClasses?: HostClasses;
    keepBoundaryWithNext?: (boundary: CellBoundary) => boolean;
    wordAddon?: Snippet<[CellWord, number]>;
    ontoggleboundary?: (boundaryId: string | number) => void;
    variantControls?: VariantControls;
  } = $props();

  const definitionFor = (variantId: string) => variantControls?.definitions[variantId];
  const wordVariant = (word: CellWord) => {
    const occurrence = variantControls?.occurrences.find(
      (item) => (
        item.anchor === 'word'
          ? String(item.anchor_word_id) === String(word.word_id)
          : item.target_word_ids.some(
            (wordId) => String(wordId) === String(word.word_id),
          )
      ),
    );
    const definition = occurrence && definitionFor(occurrence.variant_id);
    return occurrence && definition ? { occurrence, definition } : undefined;
  };
  const boundaryVariant = (boundary: CellBoundary) => {
    const occurrence = variantControls?.occurrences.find(
      (item) => item.anchor === 'boundary'
        && String(item.anchor_boundary_id) === String(boundary.boundary_id),
    );
    const definition = occurrence && definitionFor(occurrence.variant_id);
    return occurrence && definition ? { occurrence, definition } : undefined;
  };
  const hasBoundaryVariants = $derived(Boolean(
    variantControls?.occurrences.some((item) => item.anchor === 'boundary'),
  ));
  const displayText = (word: CellWord) => stripBoundaryMarks(
    word.display_text,
    undefined,
    stableLayout?.boundaries.get(word.location)?.variants
      .flatMap((boundary) => boundary.columns)
      .filter((column) => column.role === 'stop_sign')
      .map((column) => column.text) ?? [],
  );

  function hasIltiqaBoundaryBridge(
    boundary: CellBoundary | undefined, context: CellContext,
  ): boolean {
    if (!boundary) return false;
    const isIltiqa = (occurrenceId: number | string): boolean => {
      const rule = context.occurrences[String(occurrenceId)]?.rule_id;
      return typeof rule === 'string' && rule.startsWith('iltiqa_');
    };
    return (
      boundary.sounds.some((sound) => sound.rule_occurrence_ids.some(isIltiqa)) ||
      boundary.columns.some((column) =>
        column.role !== 'stop_sign' && column.rule_occurrence_ids.some(isIltiqa),
      )
    );
  }

  /** The verse a word belongs to, as `surah:ayah`. */
  const ayahOf = (location: string) => location.split(':').slice(0, 2).join(':');

  interface WordRun {
    verseBreak: boolean;
    indexes: number[];
  }

  /** Active bridge chains wrap as one reading unit. A verse edge always wins. */
  function runsOf(
    current: CellView, stable: StableLayout | undefined, flow: VerseFlow,
    keepBoundary: ((boundary: CellBoundary) => boolean) | undefined,
  ): WordRun[] {
    const runs: WordRun[] = [];
    current.words.forEach((word, index) => {
      const previous = current.words[index - 1];
      const sameAyah = previous && ayahOf(previous.location) === ayahOf(word.location);
      const sameFlow = Boolean(sameAyah) || flow === 'inline';
      const previousBoundary = current.boundaries[index - 1];
      /* Stable metadata keeps a potential bridge when this reading stops. It
         still marks a potential merger and keeps the same two words together.
         Iltiqa inserts a boundary haraka without a merger bridge and should use
         the same no-new-line policy. */
      const bridged = sameFlow && (
        Boolean(previousBoundary?.bridges.length)
        || Boolean(previous && stable?.boundaries.get(previous.location)?.potentialBridge)
        || hasIltiqaBoundaryBridge(previousBoundary, context)
        || Boolean(previousBoundary && keepBoundary?.(previousBoundary))
      );
      if (bridged) runs.at(-1)?.indexes.push(index);
      else runs.push({
        verseBreak: Boolean(previous && !sameAyah && flow === 'break'),
        indexes: [index],
      });
    });
    return runs;
  }

  const runs = $derived(runsOf(view, stableLayout, verseFlow, keepBoundaryWithNext));

  /* Read-only variant hover spotlights the cells a face changes. The spot is
     added through the host class hooks, so a row that is not spotting passes
     the host's own hooks through untouched. */
  const SPOT_CLASS = 'qc-variant-spot';
  let spot = $state.raw<VariantSpot | null>(null);

  const marked = (own: string | null | undefined, hit: boolean) =>
    hit ? [own, SPOT_CLASS].filter(Boolean).join(' ') : own;

  function withSpot(base: HostClasses, current: VariantSpot | null): HostClasses {
    if (!current) return base;
    return {
      ...base,
      column: (column, at) =>
        marked(base.column?.(column, at), current.columns.has(String(column.id))),
      sound: (sound, at) =>
        marked(base.sound?.(sound, at), current.sounds.has(String(sound.sound_id))),
      boundary: (boundary, at) => marked(
        base.boundary?.(boundary, at),
        current.boundaries.has(String(boundary.boundary_id)),
      ),
    };
  }

  const cellClasses = $derived(withSpot(hostClasses, spot));

  let tip = $state('');
  let tipX = $state(0);
  let tipY = $state(0);
  let metrics = $state<HTMLElement | null>(null);
  let root = $state<HTMLElement | null>(null);

  function hover(names: string, target: HTMLElement | null) {
    if (!showTooltips) return;
    tip = names;
    if (!names || !target) return;
    const box = target.getBoundingClientRect();
    tipX = box.left + box.width / 2;
    tipY = box.top;
  }

  function hoverVariant(
    found: { definition: VariantControlDefinition; occurrence: VariantControlOccurrence },
    option: string | null,
    target: HTMLElement | null,
  ) {
    variantControls?.onhover?.(found.occurrence.variant_id, option, found.occurrence);
    if (!variantControls?.readOnly) return;
    if (option === null) {
      spot = null;
      hover('', null);
      return;
    }
    const next = spotOf(found.occurrence, option, view.words);
    spot = isEmptySpot(next) ? null : next;
    hover(variantTip(found.definition, found.occurrence, option), target);
  }

  /**
   * Small mark cells size against a real letter box. A live cell stretches to
   * its column, so it cannot be measured; this reference one is out of flow and
   * keeps its natural width.
   */
  $effect(() => {
    if (!metrics || !root) return;
    const measure = () => {
      const box = metrics!.getBoundingClientRect();
      if (!box.width) return;
      root!.style.setProperty('--letter-cell-w', `${box.width}px`);
      root!.style.setProperty('--letter-cell-h', `${box.height}px`);
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(metrics);
    return () => observer.disconnect();
  });
</script>

<div
  class="analysis-row"
  class:has-boundary-variants={hasBoundaryVariants}
  class:has-variant-spot={spot !== null}
  dir="rtl"
  bind:this={root}
>
  <span class="letter-metrics" aria-hidden="true" bind:this={metrics}><span class="cell-ink">ب</span></span>

  <!-- A junction stays with its word; active merger chains wrap as one run. -->
  {#each runs as run (run.indexes.map((index) => view.words[index].location).join('|'))}
    {#if run.verseBreak}
      <span class="verse-break" aria-hidden="true"></span>
    {/if}
    <div class="word-run">
      {#each run.indexes as index (view.words[index].location)}
        {@const word = view.words[index]!}
        {@const wordControls = wordVariant(word)}
        <div class="word-pair">
          <WordBlock
            {word}
            displayText={displayText(word)}
            {context}
            {index}
            addon={wordAddon}
            hostClasses={cellClasses}
            state={wordState(view, index)}
            stableLayout={stableLayout?.words.get(word.location)}
            onhover={hover}
            variant={wordControls}
            onselectvariant={variantControls?.onselect}
            variantReadOnly={variantControls?.readOnly ?? false}
            onhovervariant={wordControls
              ? (option, target) => hoverVariant(wordControls, option, target)
              : undefined}
          />
          {#if view.boundaries[index]}
            {@const boundary = view.boundaries[index]}
            {@const variant = boundaryVariant(boundary)}
            <BoundaryTile
              {boundary}
              stableLayout={stableLayout?.boundaries.get(word.location)}
              {context}
              hostClasses={cellClasses}
              showMergerBridge={crossWordMergers === 'compact'}
              ontoggle={ontoggleboundary}
              onhover={hover}
              {variant}
            />
          {/if}
        </div>
      {/each}
      {#if crossWordMergers === 'extend'}
        {#each run.indexes as index (view.words[index].location)}
          {#each view.boundaries[index]?.bridges ?? [] as bridge (bridge.merger_id)}
            <CrossWordBridge {bridge} {context} hostClasses={cellClasses} onhover={hover} />
          {/each}
        {/each}
      {/if}
    </div>
  {/each}

  {#if showTooltips && tip}
    <div class="cell-tip" dir="ltr" style:left="{tipX}px" style:top="{tipY}px" aria-hidden="true">
      {#each tip.split('\n') as line (line)}
        <div>{line}</div>
      {/each}
    </div>
  {/if}
</div>

<style>
  /* Active merger chains wrap as one reading unit; verse edges start a new run. */
  .word-run {
    display: flex;
    position: relative;
    direction: rtl;
    align-items: stretch;
    gap: var(--mega-row-gap);
  }
</style>
