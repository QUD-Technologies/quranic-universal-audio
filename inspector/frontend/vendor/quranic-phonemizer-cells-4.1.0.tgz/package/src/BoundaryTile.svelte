<script lang="ts">
  import type {
    CellBoundary,
    CellContext,
    CellSound,
    HostClasses,
    VariantControlDefinition,
    VariantControlOccurrence,
  } from './types';
  import type { StableBoundaryLayout } from './union';
  import type { PhonemeBox } from './groups';
  import PhonemeCell from './PhonemeCell.svelte';
  import BoundaryMark from './BoundaryMark.svelte';
  import { waqfRenderStyle } from './waqf-render';
  import { boundaryTracks } from './boundary-layout';

  /* A junction is a flex column, not a grid: its boxes cover no tracks and are
     laid out one under the other. */
  const loose = (sound: CellSound): PhonemeBox => ({
    sound,
  });

  let {
    boundary,
    context,
    stableLayout,
    showMergerBridge = true,
    hostClasses = {},
    ontoggle,
    onhover,
    variant,
  }: {
    boundary: CellBoundary;
    context: CellContext;
    stableLayout?: StableBoundaryLayout;
    showMergerBridge?: boolean;
    hostClasses?: HostClasses;
    ontoggle?: (boundaryId: string | number) => void;
    onhover?: (names: string, target: HTMLElement | null) => void;
    variant?: {
      definition: VariantControlDefinition;
      occurrence: VariantControlOccurrence;
    };
  } = $props();

  const sign = $derived(boundary.columns.find((c) => c.role === 'stop_sign') ?? null);
  const tracks = $derived(boundaryTracks(boundary, showMergerBridge));
  const stopped = $derived(boundary.state === 'stop' || boundary.state === 'sakt');
  const verseStopped = $derived(boundary.state === 'stop');
  const verse = $derived(boundary.verse_end ?? null);
  const stopSign = $derived(sign?.text.replaceAll('\u06dc', '') ?? '');
  const visibleSign = $derived(stopSign || sign?.text || '');
  const saktSelector = $derived(
    Boolean(variant?.definition.suppress_generic_pause),
  );
  const latentSaktSign = $derived(
    stableLayout?.variants
      .flatMap((candidate) => candidate.columns)
      .find((column) => column.role === 'stop_sign' && /[ۣۜ]/u.test(column.text))
      ?.text ?? '',
  );
  const saktAvailable = $derived(
    saktSelector && !Boolean(variant?.occurrence.masked),
  );
  const saktSign = $derived(
    saktAvailable ? (visibleSign || latentSaktSign) : '',
  );
  const splitVerseSakt = $derived(Boolean(verse && saktSign));
  const toggleable = $derived(
    boundary.state !== 'sakt' || Boolean(stopSign) || Boolean(verse),
  );
  const interactive = $derived(Boolean(ontoggle) && toggleable);

  const label = $derived(
    verse
      ? !interactive
        ? `End of ayah ${verse}.`
        : verseStopped
          ? `End of ayah ${verse}. Click to read on.`
          : `Ayah ${verse} read into the next. Click to stop here.`
      : boundary.state === 'sakt' && !stopSign
      ? 'Sakt here.'
      : !interactive
      ? stopped
          ? 'Stopped boundary.'
          : 'Joined boundary.'
      : stopped
        ? 'Stop here. Click to join.'
        : 'Joined. Click to stop here.',
  );
</script>

{#snippet mark()}
    {#if verse}
      <span class="verse-glyph">{context.nativeMarkGlyphs ? verse : `\u06dd${verse}`}</span>
    {:else if saktSign}
      <span class="pause-waqf" style={waqfRenderStyle(saktSign, context.nativeMarkGlyphs)}>{saktSign}</span>
    {:else if visibleSign}
      <span class="pause-waqf" style={waqfRenderStyle(visibleSign, context.nativeMarkGlyphs)}>{visibleSign}</span>
    {:else}
      <span class="pause-icon" aria-hidden="true"></span>
    {/if}
{/snippet}

<div
  class="boundary-tile {hostClasses.boundary?.(boundary) ?? ''}"
  class:verse-tile={verse}
  data-qc-boundary-id={String(boundary.boundary_id)}
>
  {#if splitVerseSakt}
    <div class="boundary-controls" data-qc-verse-sakt>
      {#if interactive}
        <button
          type="button"
          class="pause-bridge verse-mark"
          class:stopped={verseStopped}
          aria-label={label}
          aria-pressed={verseStopped}
          onclick={() => ontoggle?.(boundary.boundary_id)}
        >
          <span class="verse-glyph">{context.nativeMarkGlyphs ? verse : `\u06dd${verse}`}</span>
        </button>
      {:else}
        <span class="pause-bridge static verse-mark" class:stopped={verseStopped} role="note" aria-label={label}>
          <span class="verse-glyph">{context.nativeMarkGlyphs ? verse : `\u06dd${verse}`}</span>
        </span>
      {/if}
      <span
        class="pause-bridge static sakt-boundary-cell"
        class:stopped={boundary.state === 'sakt'}
        role="note"
        aria-label={boundary.state === 'sakt' ? 'Sakt active.' : 'Sakt inactive.'}
      >
        <span class="pause-waqf" style={waqfRenderStyle(saktSign, context.nativeMarkGlyphs)}>{saktSign}</span>
      </span>
    </div>
  {:else if interactive}
    <button
      type="button"
      class="pause-bridge"
      class:stopped
      class:verse-mark={verse}
      aria-label={label}
      aria-pressed={stopped}
      onclick={() => ontoggle?.(boundary.boundary_id)}
    >
      {@render mark()}
    </button>
  {:else}
    <span
      class="pause-bridge static"
      class:stopped
      class:verse-mark={verse}
      role="note"
      aria-label={label}
    >
      {@render mark()}
    </span>
  {/if}

  <div class="boundary-stack">
    {#each stableLayout?.variants ?? [] as variant, variantIndex (variantIndex)}
      <div class="boundary-content boundary-layout-sizer" aria-hidden="true">
        {#each boundaryTracks(variant) as track (track.key)}
          <span class="boundary-insert-sizer" class:mark-bridge={track.column?.tier !== 'main'}>
            {#if track.column}
              <span class={track.column.tier === 'main' ? 'mega-letter' : 'dia-track'}>
                {track.column.text}
              </span>
            {/if}
            {#each track.boxes as box (box.sound.sound_id)}
              <span class="mega-phoneme">{box.sound.text}</span>
            {/each}
          </span>
        {/each}
      </div>
    {/each}

    <div class="boundary-content">
      {#each tracks as track (track.key)}
        {@const bridgeClasses = track.boxes
          .map((box) => box.bridge ? hostClasses.bridge?.(box.bridge) ?? '' : '')
          .filter(Boolean).join(' ')}
        <div
          class="crossword-bridge boundary-track {track.column ? 'borderless' : ''} {bridgeClasses}"
          class:mark-bridge={track.column?.tier !== 'main'}
          data-qc-bridge-id={track.boxes.length === 1 && track.boxes[0]?.bridge
            ? String(track.boxes[0].bridge.merger_id) : undefined}
        >
          {#if track.column}
            <BoundaryMark column={track.column} {context} {hostClasses} {onhover} />
          {/if}
          {#each track.boxes as box (box.sound.sound_id)}
            <PhonemeCell box={loose(box.sound)} {context} {hostClasses} {onhover} />
          {/each}
        </div>
      {/each}
    </div>
  </div>
</div>
