<script lang="ts">
  /**
   * Numbered option controls for one variant occurrence. Interactive mode
   * reports a click through `onselect`; `readOnly` shows the selection without
   * changing it and reports hover and focus through `onhover` instead.
   */
  import type {
    VariantControlDefinition,
    VariantControlOccurrence,
  } from './types';
  import { optionLabel, optionName } from './variant-label';

  let {
    definition,
    occurrence,
    anchor,
    overlay = false,
    showOptionNames = false,
    readOnly = false,
    onselect,
    onhover,
  }: {
    definition: VariantControlDefinition;
    occurrence: VariantControlOccurrence;
    anchor: 'word' | 'boundary';
    overlay?: boolean;
    showOptionNames?: boolean;
    readOnly?: boolean;
    onselect?: (
      variantId: string,
      option: string,
      occurrence: VariantControlOccurrence,
    ) => void;
    onhover?: (option: string | null, target: HTMLElement | null) => void;
  } = $props();

  const stateOf = (option: string) =>
    occurrence.selected === option
      ? 'chosen'
      : definition.default === option ? 'default' : 'other';
  const threeOptions = $derived(showOptionNames && definition.options.length === 3);
  const longPair = $derived(
    showOptionNames
      && definition.options.length === 2
      && definition.options.some((option) => optionName(option).length > 11),
  );
</script>

<div
  class="variant-selector"
  class:boundary={anchor === 'boundary'}
  class:overlay
  class:named={showOptionNames}
  class:three-options={threeOptions}
  class:long-pair={longPair}
  class:masked={occurrence.masked}
  class:read-only={readOnly}
  role="group"
  aria-label={definition.display_name}
  data-qc-variant={definition.id}
>
  <div class="variant-options" dir="ltr">
    {#each definition.options as option, index (option)}
      {@const selected = occurrence.selected === option}
      {@const isDefault = definition.default === option}
      <button
        type="button"
        class:selected
        class:default={isDefault}
        aria-pressed={selected}
        aria-disabled={readOnly ? 'true' : undefined}
        aria-label={optionLabel(definition, option)}
        title={readOnly ? undefined : optionLabel(definition, option)}
        data-qc-variant-option={option}
        data-qc-variant-state={stateOf(option)}
        onclick={() => { if (!readOnly) onselect?.(definition.id, option, occurrence); }}
        onpointerenter={(event) => onhover?.(option, event.currentTarget)}
        onpointerleave={() => onhover?.(null, null)}
        onfocus={(event) => onhover?.(option, event.currentTarget)}
        onblur={() => onhover?.(null, null)}
      >
        <span class="option-number">{index + 1}</span>
        {#if showOptionNames}<span class="option-name">{optionName(option)}</span>{/if}
      </button>
    {/each}
  </div>
</div>

<style>
  .variant-selector {
    display: grid;
    position: relative;
    z-index: 2;
    max-inline-size: 100%;
    min-block-size: 1.55rem;
    place-items: center;
    direction: ltr;
  }

  .overlay {
    position: absolute;
    top: 0;
    left: 50%;
    z-index: 4;
    min-block-size: 0;
    pointer-events: none;
    transform: translate(-50%, -55%);
  }

  .boundary.overlay {
    top: 0;
    transform: translate(-50%, calc(-100% - 1rem));
  }

  .variant-options {
    display: inline-flex;
    gap: 0.22rem;
    padding: 0.16rem;
    border: 1px solid var(--line, #d5dadd);
    border-radius: 999px;
    background: var(--surface, #fff);
    box-shadow: 0 1px 3px color-mix(in srgb, var(--ink, #172126) 10%, transparent);
    pointer-events: auto;
  }

  button {
    display: grid;
    inline-size: 1.25rem;
    block-size: 1.25rem;
    padding: 0;
    place-items: center;
    border: 1px solid transparent;
    border-radius: 50%;
    background: transparent;
    color: var(--ink-muted, #667177);
    font: 600 0.68rem/1 var(--font-sans, system-ui, sans-serif);
    cursor: pointer;
    transition: background 160ms ease, border-color 160ms ease, color 160ms ease;
  }

  .named button {
    display: inline-flex;
    inline-size: auto;
    min-inline-size: 0;
    block-size: 1.75rem;
    gap: 0.35rem;
    padding-inline: 0.5rem;
    border-radius: 999px;
  }

  .named.three-options .variant-options,
  .named.long-pair .variant-options {
    display: grid;
    box-sizing: border-box;
    inline-size: 100%;
    max-inline-size: 100%;
    border-radius: 1rem;
  }

  .named.three-options,
  .named.long-pair {
    inline-size: min(100%, 10rem);
  }

  .named.three-options .variant-options {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .named.three-options button {
    inline-size: 100%;
    justify-content: center;
  }

  .named.three-options button:nth-child(3) {
    grid-column: 1 / -1;
    inline-size: 100%;
    justify-content: center;
  }

  .named.long-pair .variant-options {
    grid-template-columns: minmax(0, 1fr);
  }

  .named.long-pair button {
    inline-size: 100%;
    justify-content: center;
  }

  .option-number {
    font-variant-numeric: tabular-nums;
  }

  .option-name {
    white-space: nowrap;
    font-size: 0.72rem;
    font-weight: 650;
  }

  button:hover,
  button:focus-visible {
    color: var(--accent, #087f75);
    outline: none;
  }

  button:focus-visible {
    box-shadow: 0 0 0 2px var(--surface, #fff), 0 0 0 4px var(--accent, #087f75);
  }

  button.default {
    border-color: var(--accent, #087f75);
  }

  button.selected {
    border-color: var(--accent, #087f75);
    background: var(--accent, #087f75);
    color: var(--surface, #fff);
  }

  button.selected.default {
    box-shadow: 0 0 0 2px var(--surface, #fff), 0 0 0 3px var(--accent, #087f75);
  }

  .read-only button {
    cursor: default;
  }

  .masked .variant-options {
    border-style: dashed;
  }

  .boundary {
    min-inline-size: 1.5rem;
  }

  @media (prefers-reduced-motion: reduce) {
    button { transition: none; }
  }
</style>
