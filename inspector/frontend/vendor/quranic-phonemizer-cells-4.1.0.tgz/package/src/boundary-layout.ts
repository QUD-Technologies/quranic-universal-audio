import type { CellBoundary, CellColumn, CellSound, CellBridge } from './types';

export interface BoundarySoundBox {
  sound: CellSound;
  bridge?: CellBridge;
}

export interface BoundaryTrack {
  key: string;
  column?: CellColumn;
  boxes: BoundarySoundBox[];
}

const touches = (bridge: CellBridge, column: CellColumn): boolean =>
  [...bridge.before_column_ids, ...bridge.after_column_ids].includes(column.id);

export function boundaryTracks(
  boundary: CellBoundary, includeBridges = true,
): BoundaryTrack[] {
  const inserted = boundary.columns.filter((column) => column.role !== 'stop_sign');
  const claimed = new Set<string>();
  const tracks = inserted.map((column): BoundaryTrack => {
    const bridges = includeBridges
      ? boundary.bridges.filter((bridge) => touches(bridge, column))
      : [];
    bridges.forEach((bridge) => claimed.add(String(bridge.merger_id)));
    const bridgedSounds = new Set(bridges.map((bridge) => String(bridge.sound.sound_id)));
    const native = boundary.sounds.filter((sound) =>
      sound.column_ids.includes(column.id) && !bridgedSounds.has(String(sound.sound_id))
    );
    return {
      key: `column:${String(column.id)}`,
      column,
      boxes: [
        ...bridges.map((bridge) => ({ sound: bridge.sound, bridge })),
        ...native.map((sound) => ({ sound })),
      ],
    };
  });
  if (!includeBridges) return tracks;
  return [
    ...tracks,
    ...boundary.bridges
      .filter((bridge) => !claimed.has(String(bridge.merger_id)))
      .map((bridge): BoundaryTrack => ({
        key: `bridge:${String(bridge.merger_id)}`,
        boxes: [{ sound: bridge.sound, bridge }],
      })),
  ];
}
