import type { CellColumn, CellId, CellSound, CellWord } from './types';

export const isSilentColumn = (column: CellColumn): boolean =>
  column.silence !== null
  || (column.owned_sound_ids.length === 0 && column.presented_sound_ids.length === 0);

export function soundLayoutColumnIds(
  word: CellWord, sound: CellSound,
): CellId[] {
  const columns = new Map(word.columns.map((column) => [column.id, column]));
  return sound.column_ids.filter((id) => columns.get(id)?.silence === null);
}

export function shapeOf(column: CellColumn) {
  if (column.tier === 'main') return { size: 'full' as const, pin: null };
  return {
    size: 'small' as const,
    pin: column.tier === 'below' ? ('bottom' as const) : ('top' as const),
  };
}
