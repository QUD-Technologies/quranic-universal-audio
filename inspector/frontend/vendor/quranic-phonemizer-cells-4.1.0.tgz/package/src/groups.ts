import type { CellColumn, CellId, CellWord } from './types';
import {
  collectSeams, groupSoundConstraints,
  LayoutInvariantError,
  matchingVariant,
  slotKeys,
  type StableGroupVariant,
  type StableSeam,
  type StableWordLayout,
  type StableWordVariant,
} from './union';
import { materializeDormantIqlab } from './visual';
import { dormantStableSlot, materializeStableDuplicates } from './stable-duplicates';
import { isSilentColumn, shapeOf } from './column-shape';
import { crossGroupSpans, localSoundSpans } from './sound-layout';
import type {
  LayoutGroup,
  PhonemeSpan,
  TrackSpan,
  WordLayout,
  WordPhonemeSpan,
} from './layout-types';
export type {
  GlyphSizer,
  GroupColumn,
  GroupKind,
  LayoutGroup,
  PhonemeBox,
  PhonemeSpan,
  SoundSizer,
  TrackSpan,
  WordPhonemeSpan,
  WordLayout,
} from './layout-types';

export { isSilentColumn } from './column-shape';

function currentVariant(
  word: CellWord, state: string, plan?: StableWordLayout,
): StableWordVariant {
  const rawKeys = slotKeys(word);
  const reference = plan && matchingVariant(plan, word, state);
  const physicalByStem = new Map(reference?.keys.map((key) => [
    key.replace(/\|stable:\d+$/, ''), key,
  ]) ?? []);
  const keyById = new Map(word.columns.map((column, at) => [
    column.id,
    dormantStableSlot(word, column.id)
      ?? physicalByStem.get(rawKeys[at]!)
      ?? rawKeys[at]!,
  ]));
  const grouped = word.groups.flatMap((group) =>
    group.column_ids.map((id) => keyById.get(id)!)
  );
  const claimed = new Set(grouped);
  const mappedKeys = word.columns.map((column) => keyById.get(column.id)!);
  const keys = [...grouped, ...mappedKeys.filter((key) => !claimed.has(key))];
  const groups = word.groups.map((group): StableGroupVariant => ({
    host: keyById.get(group.key) ?? missing(word, state, `group host ${String(group.key)}`),
    kind: group.kind,
    slots: group.column_ids.map((id) =>
      keyById.get(id) ?? missing(word, state, `group column ${String(id)}`)
    ),
    soundIds: [...group.sound_ids],
  }));
  return { state, word, keys, keyById, groups };
}

function missing(word: CellWord, state: string, detail: string): never {
  throw new LayoutInvariantError(`${word.location} ${state}: missing ${detail}`);
}

interface Tracks {
  at: Map<string, number>;
  count: number;
}

function tracksOf(plan: StableWordLayout): Tracks {
  return {
    at: new Map(plan.slots.map((slot, at) => [slot, at])),
    count: plan.slots.length,
  };
}

const groupOf = (variant: StableWordVariant, slot: string) =>
  variant.groups.find((group) => group.slots.includes(slot));

function seamsByCut(seams: StableSeam[]): StableSeam[][] {
  const grouped = new Map<number, StableSeam[]>();
  for (const seam of seams) {
    const cut = grouped.get(seam.after) ?? [];
    cut.push(seam);
    grouped.set(seam.after, cut);
  }
  return [...grouped.values()];
}

function seamIsActive(current: StableWordVariant, seam: StableSeam): boolean {
  const left = groupOf(current, seam.left);
  const right = groupOf(current, seam.right);
  return Boolean(left && right && left !== right);
}

function intersection(groups: StableGroupVariant[]): Set<string> {
  if (groups.length === 0) return new Set();
  return new Set(groups[0]!.slots.filter((slot) =>
    groups.slice(1).every((group) => group.slots.includes(slot))
  ));
}

function absentAbsorber(
  plan: StableWordLayout, current: StableWordVariant, slot: string,
): string {
  const donorPairs = [...plan.variants.values()].flatMap((variant) => {
    const group = groupOf(variant, slot);
    return group ? [{ variant, group }] : [];
  });
  const donors = donorPairs.map(({ group }) => group);
  const present = new Set(current.keys);
  const slotAt = plan.slots.indexOf(slot);
  const position = new Map(plan.slots.map((key, at) => [key, at]));
  const contiguousFrom = (key: string) => {
    const keyAt = position.get(key);
    if (keyAt === undefined) return false;
    const from = Math.min(keyAt, slotAt) + 1;
    const through = Math.max(keyAt, slotAt);
    return plan.slots.slice(from, through).every((between) => !present.has(between));
  };
  const hosts = [...new Set(donors.map((group) => group.host))]
    .filter((host) => present.has(host) && contiguousFrom(host));
  if (hosts.length === 1) return hosts[0]!;
  const candidates = [...intersection(donors)]
    .filter((key) => present.has(key) && contiguousFrom(key));
  if (candidates.length === 1) {
    const currentGroup = groupOf(current, candidates[0]!);
    const rankedMembers = (currentGroup?.slots ?? candidates)
      .filter((key) => present.has(key) && contiguousFrom(key))
      .map((key) => ({ key, distance: Math.abs(plan.slots.indexOf(key) - slotAt) }))
      .sort((left, right) => left.distance - right.distance);
    if (
      rankedMembers.length > 0
      && (rankedMembers.length === 1
        || rankedMembers[0]!.distance < rankedMembers[1]!.distance)
    ) return rankedMembers[0]!.key;
    return candidates[0]!;
  }
  const adjacent = [plan.slots[slotAt - 1], plan.slots[slotAt + 1]]
    .filter((key): key is string => key !== undefined && present.has(key));
  if (adjacent.length === 1) return adjacent[0]!;
  const donorTiers = new Set(donorPairs.flatMap(({ variant }) =>
    variant.word.columns.flatMap((column) =>
      variant.keyById.get(column.id) === slot ? [column.tier] : []
    )
  ));
  const tierAdjacent = adjacent.filter((key) => current.word.columns.some((column) =>
    current.keyById.get(column.id) === key && donorTiers.has(column.tier)
  ));
  if (tierAdjacent.length === 1) return tierAdjacent[0]!;
  /* A transformed compound can fold several source characters into one main
     cell, or expand them back into a base and mark. Match the complete source
     character inventory, then use stable reading order to select the adjacent
     expanded cell. This preserves a single contiguous range in both directions. */
  const donorCharacters = new Set(donorPairs.flatMap(({ variant }) =>
    variant.word.columns.flatMap((column) =>
      variant.keyById.get(column.id) === slot
        ? column.source_character_ids.map(String) : []
    )
  ));
  const sourceSlots = [...new Set(current.word.columns.flatMap((column) => {
    if (!column.source_character_ids.some((id) => donorCharacters.has(String(id)))) return [];
    const key = current.keyById.get(column.id);
    return key === undefined || !contiguousFrom(key) ? [] : [key];
  }))];
  const rankedSourceSlots = sourceSlots
    .map((key) => ({ key, distance: Math.abs(plan.slots.indexOf(key) - slotAt) }))
    .sort((left, right) => left.distance - right.distance);
  if (
    rankedSourceSlots.length > 0
    && (rankedSourceSlots.length === 1
      || rankedSourceSlots[0]!.distance < rankedSourceSlots[1]!.distance)
  ) return rankedSourceSlots[0]!.key;
  /* A transformed projection can collapse a donor into a source-backed
     compound. Resolve that from shared source-unit identity, never geometry. */
  const donorUnits = new Set(donorPairs.flatMap(({ variant, group }) =>
    variant.word.columns
      .filter((column) => group.slots.includes(variant.keyById.get(column.id)!))
      .flatMap((column) => column.source_unit_ids.map(String))
  ));
  const sourceHosts = [...new Set(current.word.columns.flatMap((column) => {
    if (!column.source_unit_ids.some((unit) => donorUnits.has(String(unit)))) return [];
    const key = current.keyById.get(column.id);
    const group = key === undefined ? undefined : groupOf(current, key);
    return group && contiguousFrom(group.host) ? [group.host] : [];
  }))];
  if (sourceHosts.length === 1) return sourceHosts[0]!;
  /* A variant can materialize an unwritten letter/haraka as its own group
     beside a source unit (Tamanna ikhtilas). In the compact face that group is
     absent, so its declared anchor unit is the only semantic owner of the
     latent tracks. */
  const anchorUnits = new Set(donorPairs.flatMap(({ variant, group }) =>
    variant.word.columns
      .filter((column) => group.slots.includes(variant.keyById.get(column.id)!))
      .flatMap((column) => column.anchor_unit_id === null
        ? [] : [String(column.anchor_unit_id)])
  ));
  const anchorHosts = [...new Set(current.word.columns.flatMap((column) => {
    if (!column.source_unit_ids.some((unit) => anchorUnits.has(String(unit)))) return [];
    const key = current.keyById.get(column.id);
    const group = key === undefined ? undefined : groupOf(current, key);
    return group && contiguousFrom(group.host) ? [group.host] : [];
  }))];
  if (anchorHosts.length === 1) return anchorHosts[0]!;
  throw new LayoutInvariantError(
    `${plan.location} ${current.state}: slot ${slot} has ${candidates.length} absorbers `
      + `[${candidates.join(',')}], donors ${donors.map((group) => group.slots.join('+')).join(';')}`,
  );
}

function seamAbsorber(
  plan: StableWordLayout, current: StableWordVariant, seam: StableSeam,
): string {
  const position = new Map(plan.slots.map((slot, at) => [slot, at]));
  const present = new Set(current.keys);
  const adjacentMissing = [seam.left, seam.right]
    .filter((slot) => slot !== undefined && !present.has(slot))
    .map((slot) => absentAbsorber(plan, current, slot));
  const adjacent = [...new Set(adjacentMissing)];
  if (adjacent.length === 1) return adjacent[0]!;
  const crossing = current.groups.filter((group) => {
    const places = group.slots.map((slot) => position.get(slot) ?? -1);
    return Math.min(...places) <= seam.after && Math.max(...places) > seam.after;
  });
  const active = [...plan.variants.values()].filter((variant) =>
    seam.activeStates.has(variant.state)
  );
  const candidates = crossing.flatMap((group) => active.flatMap((variant) =>
    group.slots.flatMap((slot) => {
      const donor = groupOf(variant, slot);
      return donor && donor.host !== group.host && present.has(donor.host) ? [donor.host] : [];
    })
  ));
  const movingMembers = crossing.length === 1
    ? [seam.left, seam.right].filter((slot) => {
        const currentGroup = crossing[0]!;
        if (slot === currentGroup.host || !currentGroup.slots.includes(slot)) return false;
        const signature = `${currentGroup.host}|${currentGroup.slots.join('+')}`;
        return active.some((variant) => {
          const donor = groupOf(variant, slot);
          return donor && `${donor.host}|${donor.slots.join('+')}` !== signature;
        });
      })
    : [];
  /* A changed native host is the moving member. When the host stays fixed,
     the one non-host seam endpoint whose group signature changes is. */
  const changedHosts = [...new Set(candidates)];
  const unique = changedHosts.length > 0 ? changedHosts : [...new Set(movingMembers)];
  if (unique.length !== 1) throw new LayoutInvariantError(
    `${plan.location} ${current.state}: seam ${seam.id} has ${unique.length} absorbers `
      + `[${unique.join(',')}], adjacent [${adjacentMissing.join(',')}], `
      + `present ${present.has(seam.left)}/${present.has(seam.right)}, crossing `
      + `${crossing.map((group) => `${group.host}:${group.slots.join('+')}`).join(';')}`,
  );
  return unique[0]!;
}

function capacities(
  plan: StableWordLayout, current: StableWordVariant, tracks: Tracks,
): {
  owned: Map<string, number[]>;
  seamCapacity: Map<string, number>;
  seams: WordLayout['seams'];
} {
  const owned = new Map(current.keys.map((slot) => [slot, [tracks.at.get(slot)!]]));
  const seamCapacity = new Map(current.keys.map((slot) => [slot, 0]));
  const seams: WordLayout['seams'] = [];
  for (const slot of plan.slots) {
    if (owned.has(slot)) continue;
    owned.get(absentAbsorber(plan, current, slot))!.push(tracks.at.get(slot)!);
  }
  for (const cut of seamsByCut(plan.seams)) {
    const active = cut.filter((seam) => seamIsActive(current, seam));
    if (active.length > 0) {
      cut.forEach((seam) => seams.push({ id: seam.id, active: true, absorber: null }));
      continue;
    }
    const absorbers = [...new Set(cut.map((seam) => seamAbsorber(plan, current, seam)))];
    if (absorbers.length !== 1) throw new LayoutInvariantError(
      `${plan.location} ${current.state}: seam cut ${cut[0]!.after} has `
        + `${absorbers.length} absorbers [${absorbers.join(',')}]`,
    );
    const absorber = absorbers[0]!;
    seamCapacity.set(absorber, seamCapacity.get(absorber)! + 1);
    cut.forEach((seam) => seams.push({ id: seam.id, active: false, absorber }));
  }
  return { owned, seamCapacity, seams };
}

function rangeOf(values: number[], where: string): TrackSpan {
  const sorted = [...new Set(values)].sort((a, b) => a - b);
  if (sorted.length === 0) throw new LayoutInvariantError(`${where}: empty track range`);
  if (sorted.at(-1)! - sorted[0]! + 1 !== sorted.length) throw new LayoutInvariantError(
    `${where}: non-contiguous tracks ${sorted.join(',')}`,
  );
  return { at: sorted[0]!, span: sorted.length };
}

const runOf = (word: CellWord, group: CellWord['groups'][number]): number =>
  word.runs.findIndex((run) =>
    group.column_ids.some((id) => run.column_ids.includes(id))
  );

function groupsOfVariant(
  word: CellWord,
  variant: StableWordVariant,
  owned: Map<string, number[]>,
  seamCapacity: Map<string, number>,
  plan: StableWordLayout,
): LayoutGroup[] {
  const columns = new Map(word.columns.map((column) => [column.id, column]));
  const cellRanges = new Map<string, TrackSpan>();
  owned.forEach((value, slot) => cellRanges.set(
    slot, rangeOf(value, `${word.location} ${variant.state} slot ${slot}`),
  ));
  return word.groups.map((raw, index) => {
    const stable = variant.groups[index]
      ?? missing(word, variant.state, `stable group ${String(raw.key)}`);
    const groupTracks = stable.slots.flatMap((slot) => {
      const range = cellRanges.get(slot)!;
      return Array.from({ length: range.span }, (_, at) => range.at + at);
    });
    const range = rangeOf(
      groupTracks,
      `${word.location} ${variant.state} group ${String(raw.key)} `
        + `${stable.slots.join('+')} (${groupTracks.join(',')})`,
    );
    const cols = raw.column_ids.map((id) => {
      const column = columns.get(id) ?? missing(word, variant.state, `column ${String(id)}`);
      const slot = variant.keyById.get(id)!;
      const own = cellRanges.get(slot)!;
      return {
        slot,
        column,
        ...shapeOf(column),
        at: own.at - range.at,
        span: own.span,
        seamCapacity: seamCapacity.get(slot) ?? 0,
      };
    });
    const spans = localSoundSpans(word, raw, variant, cellRanges, range.at);
    const covered = new Set(spans.flatMap((span) =>
      Array.from({ length: span.span }, (_, at) => span.at + at)
    ));
    for (const col of cols) {
      const positions = Array.from({ length: col.span }, (_, at) => col.at + at);
      if (positions.some((at) => covered.has(at))) continue;
      spans.push({ at: col.at, span: col.span, boxes: [] });
    }
    return {
      key: raw.key,
      raw,
      kind: raw.kind,
      ...range,
      cols,
      spans,
      gapAfter: Number(plan.seams.some((seam) =>
        seamIsActive(variant, seam)
        && stable.slots.includes(seam.left)
        && variant.groups.some((next) => next !== stable && next.slots.includes(seam.right))
      )),
      runGapAfter: Number(
        word.groups[index + 1] !== undefined
        && runOf(word, raw) !== runOf(word, word.groups[index + 1]!),
      ),
    };
  });
}

function seamBudgets(
  plan: StableWordLayout,
  current: StableWordVariant,
  inactive: Map<string, number>,
): Map<string, number> {
  const budgets = new Map(plan.slots.map((slot) => [slot, 0]));
  inactive.forEach((count, slot) => budgets.set(slot, count));
  for (const cut of seamsByCut(plan.seams)) {
    const active = cut.filter((seam) => seamIsActive(current, seam));
    if (active.length === 0) continue;
    const owner = plan.slots[cut[0]!.after]
      ?? missing(current.word, current.state, `seam owner at ${cut[0]!.after}`);
    budgets.set(owner, (budgets.get(owner) ?? 0) + 1);
  }
  return budgets;
}

function soundSizingConstraints(plan: StableWordLayout, tracks: Tracks) {
  const constraints = new Map<string, Omit<WordLayout['sounds'][number], 'seamCapacity'>>();
  const add = (span: PhonemeSpan) => {
    if (span.boxes.length === 0) return;
    const sounds = span.boxes.map((box) => box.sound);
    const signature = `${span.at}|${span.span}|${sounds.map((sound) => sound.text).join('|')}`;
    constraints.set(signature, { at: span.at, span: span.span, sounds });
  };
  for (const source of plan.variants.values()) {
    const word = materializeDormantIqlab(source.word, plan);
    const variant = currentVariant(word, source.state, plan);
    const capacity = capacities(plan, variant, tracks);
    const groups = groupsOfVariant(
      word, variant, capacity.owned, capacity.seamCapacity, plan,
    );
    for (const group of groups) {
      for (const span of group.spans) {
        add({ ...span, at: group.at + span.at });
      }
    }
    crossGroupSpans(word, groups).forEach(add);
  }
  for (const constraint of plan.sounds) {
    const positions = constraint.slots.map((slot) => tracks.at.get(slot)!)
      .filter((at) => at !== undefined);
    if (positions.length === 0) continue;
    const at = Math.min(...positions);
    add({
      at,
      span: Math.max(...positions) - at + 1,
      boxes: constraint.sounds.map((sound) => ({ sound })),
    });
  }
  return [...constraints.values()];
}

function sizers(
  plan: StableWordLayout,
  current: StableWordVariant,
  inactive: Map<string, number>,
  tracks: Tracks,
) {
  const budgets = seamBudgets(plan, current, inactive);
  const stableBudgets = new Map(budgets);
  for (const candidate of plan.variants.values()) {
    const candidateCapacity = capacities(plan, candidate, tracks).seamCapacity;
    const candidateBudgets = seamBudgets(plan, candidate, candidateCapacity);
    for (const [slot, capacity] of candidateBudgets) {
      stableBudgets.set(slot, Math.max(stableBudgets.get(slot) ?? 0, capacity));
    }
  }
  const glyphs = plan.glyphs.map(({ slot, column }) => ({
    at: tracks.at.get(slot)!,
    column,
    seamCapacity: stableBudgets.get(slot) ?? 0,
  }));
  const sounds = soundSizingConstraints(plan, tracks).map((constraint) => ({
    ...constraint,
    seamCapacity: plan.slots.slice(constraint.at, constraint.at + constraint.span)
      .reduce((total, slot) => total + (stableBudgets.get(slot) ?? 0), 0),
  }));
  return { glyphs, sounds };
}

function naturalPlan(word: CellWord, state: string): StableWordLayout {
  const variant = currentVariant(word, state);
  return {
    location: word.location,
    slots: variant.keys,
    seams: collectSeams(variant.keys, [variant]),
    variants: new Map([[state, variant]]),
    glyphs: word.columns.map((column) => ({ slot: variant.keyById.get(column.id)!, column })),
    sounds: groupSoundConstraints(variant),
  };
}

export function layoutWord(
  word: CellWord, state = 'natural', stable?: StableWordLayout,
): WordLayout {
  const plan = stable ?? naturalPlan(word, state);
  const rendered = stable
    ? materializeDormantIqlab(materializeStableDuplicates(word, state, plan), plan)
    : word;
  const variant = currentVariant(rendered, state, stable ? plan : undefined);
  const unknown = variant.keys.filter((slot) => !plan.slots.includes(slot));
  if (unknown.length > 0) throw new LayoutInvariantError(
    `${word.location} ${state}: unknown slots ${unknown.join(',')} `
      + `(plan states ${[...plan.variants.keys()].join(',')})`,
  );
  const tracks = tracksOf(plan);
  const capacity = capacities(plan, variant, tracks);
  const groups = groupsOfVariant(
    rendered, variant, capacity.owned, capacity.seamCapacity, plan,
  );
  const spans = crossGroupSpans(rendered, groups);
  const sizing = sizers(plan, variant, capacity.seamCapacity, tracks);
  return {
    trackCount: tracks.count,
    template: `repeat(${tracks.count}, max-content)`,
    groups,
    spans,
    ...sizing,
    seams: capacity.seams,
    descriptor: JSON.stringify({
      tracks: tracks.count,
      glyphs: sizing.glyphs.map((one) => [
        one.at, one.column.tier, one.column.text,
      ]),
      sounds: sizing.sounds.map((one) => [
        one.at, one.span, one.sounds.map((sound) => sound.text),
      ]),
      seams: seamsByCut(plan.seams).length,
    }),
  };
}

export const groupsOf = (word: CellWord): LayoutGroup[] => layoutWord(word).groups;

export function occurrencesOn(column: CellColumn): CellId[] {
  return column.rule_occurrence_ids;
}
