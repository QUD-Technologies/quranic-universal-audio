import type { CellColumn, CellId, CellWord } from './types';
import {
  LayoutInvariantError,
  matchingVariant,
  type StableWordLayout,
} from './union';

const prefixFor = (word: CellWord) =>
  `visual:dormant:stable:${word.location}:`;

export function dormantStableSlot(
  word: CellWord, id: CellId,
): string | undefined {
  const value = String(id);
  const prefix = prefixFor(word);
  return value.startsWith(prefix) ? value.slice(prefix.length) : undefined;
}

/** Hold both physical positions of a source mark that changes native host. */
export function materializeStableDuplicates(
  word: CellWord, state: string, plan: StableWordLayout,
): CellWord {
  const reference = matchingVariant(plan, word, state);
  if (!reference) return word;
  const order = new Map(plan.slots.map((slot, at) => [slot, at]));
  let rendered = word;
  for (const slot of plan.slots) {
    if (!slot.includes('|stable:') || reference.keys.includes(slot)) continue;
    const donor = plan.glyphs.find((glyph) => glyph.slot === slot)?.column;
    if (!donor) continue;
    const hosts = [...new Set([...plan.variants.values()].flatMap((variant) => {
      const group = variant.groups.find((candidate) => candidate.slots.includes(slot));
      return group && reference.groups.some((current) => current.host === group.host)
        ? [group.host]
        : [];
    }))];
    if (hosts.length !== 1) throw new LayoutInvariantError(
      `${word.location} ${state}: duplicated slot ${slot} has ${hosts.length} dormant hosts`,
    );
    const groupAt = reference.groups.findIndex((group) => group.host === hosts[0]);
    const raw = rendered.groups[groupAt];
    if (!raw) throw new LayoutInvariantError(
      `${word.location} ${state}: duplicated slot ${slot} has no native group`,
    );
    const id = `${prefixFor(word)}${slot}`;
    const placeholder: CellColumn = {
      ...donor,
      id,
      text: '',
      source_character_ids: [],
      source_unit_ids: [],
      slot_ids: [],
      status: 'dropped',
      silence: 'stable_placeholder',
      owned_sound_ids: [],
      presented_sound_ids: [],
      rule_occurrence_ids: [],
    };
    const physical = (columnId: CellId) =>
      columnId === id ? slot : reference.keyById.get(columnId)!;
    const ids = [...raw.column_ids, id].sort((left, right) =>
      order.get(physical(left))! - order.get(physical(right))!
    );
    rendered = {
      ...rendered,
      columns: [...rendered.columns, placeholder],
      groups: rendered.groups.map((group, index) =>
        index === groupAt ? { ...group, column_ids: ids } : group
      ),
    };
  }
  return rendered;
}
