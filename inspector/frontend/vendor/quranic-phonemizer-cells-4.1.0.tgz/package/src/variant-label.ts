/** Display text for variant options: humanized IDs and the read-only tooltip. */
import type { VariantControlDefinition, VariantControlOccurrence } from './types';

export const optionName = (option: string): string =>
  option.replaceAll('_', ' ').replace(/^./, (letter) => letter.toUpperCase());

export const optionLabel = (definition: VariantControlDefinition, option: string): string =>
  `${definition.display_name}: ${optionName(option)}`;

/** Tooltip lines: the face, the selector's description, and the selection note. */
export function variantTip(
  definition: VariantControlDefinition,
  occurrence: VariantControlOccurrence,
  option: string,
): string {
  const note = option === occurrence.selected ? occurrence.note : undefined;
  const lines = [optionLabel(definition, option), definition.description, note];
  return [...new Set(lines.filter(Boolean))].join('\n');
}
