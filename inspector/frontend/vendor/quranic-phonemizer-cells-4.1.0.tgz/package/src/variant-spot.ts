/**
 * Which native entities a read-only variant option spotlights.
 *
 * The producer lists, per non-selected option, the cells that face would
 * change. The selected option spotlights the union of those lists. An option
 * without a list falls back to the occurrence's target words, when the caller
 * supplies them. IDs are compared as strings, as elsewhere in the renderer.
 */
import type {
  CellId,
  CellWord,
  VariantAffectedCells,
  VariantControlOccurrence,
} from './types';

export interface VariantSpot {
  columns: Set<string>;
  sounds: Set<string>;
  boundaries: Set<string>;
}

const emptySpot = (): VariantSpot => ({
  columns: new Set(),
  sounds: new Set(),
  boundaries: new Set(),
});

const addAll = (into: Set<string>, ids: readonly CellId[]) => {
  for (const id of ids) into.add(String(id));
};

function addCells(spot: VariantSpot, cells: VariantAffectedCells): void {
  addAll(spot.columns, cells.column_ids);
  addAll(spot.sounds, cells.sound_ids);
  addAll(spot.boundaries, cells.boundary_ids);
}

function targetWordSpot(occurrence: VariantControlOccurrence, words: readonly CellWord[]): VariantSpot {
  const spot = emptySpot();
  const targets = new Set(occurrence.target_word_ids.map(String));
  for (const word of words) {
    if (!targets.has(String(word.word_id))) continue;
    addAll(spot.columns, word.columns.map((column) => column.id));
    addAll(spot.sounds, word.sounds.map((sound) => sound.sound_id));
  }
  return spot;
}

/** The entities `option` spotlights; `words` resolves the target-word fallback. */
export function spotOf(
  occurrence: VariantControlOccurrence,
  option: string,
  words: readonly CellWord[] = [],
): VariantSpot {
  const affected = occurrence.affected;
  if (affected && option === occurrence.selected) {
    const spot = emptySpot();
    for (const cells of Object.values(affected)) addCells(spot, cells);
    return spot;
  }
  const cells = affected?.[option];
  if (!cells) return targetWordSpot(occurrence, words);
  const spot = emptySpot();
  addCells(spot, cells);
  return spot;
}

export const isEmptySpot = (spot: VariantSpot): boolean =>
  spot.columns.size + spot.sounds.size + spot.boundaries.size === 0;
